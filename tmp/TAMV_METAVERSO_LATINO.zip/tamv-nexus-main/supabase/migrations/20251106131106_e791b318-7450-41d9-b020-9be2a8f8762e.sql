-- ============================================================================
-- TAMV DM-X4™ Database Schema - Complete Infrastructure
-- ============================================================================

-- 1. ENUMS Y TIPOS CUSTOM
CREATE TYPE public.app_role AS ENUM ('admin', 'architect', 'ambassador', 'curator', 'strategist', 'analyst', 'user');
CREATE TYPE public.emotion_type AS ENUM ('trust', 'inspiration', 'authority', 'care', 'empathy', 'conflict', 'resolve', 'joy', 'fear', 'surprise', 'sadness', 'disgust', 'anger', 'anticipation', 'neutral');
CREATE TYPE public.modality_type AS ENUM ('visual', 'audio', 'tactile', 'hybrid');
CREATE TYPE public.compliance_level AS ENUM ('green', 'yellow', 'red');
CREATE TYPE public.asset_type AS ENUM ('dreamspace', 'nft', 'artwork', 'course', 'template', 'quantum_pet');

-- 2. TABLA DE PERFILES (Quantum Identity)
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  username TEXT UNIQUE NOT NULL,
  display_name TEXT,
  avatar_url TEXT,
  bio TEXT,
  id_nvida TEXT UNIQUE, -- Identidad Quantum única
  quantum_signature TEXT, -- Hash cuántico de identidad
  emotion_state emotion_type DEFAULT 'neutral',
  emotion_intensity FLOAT DEFAULT 0.5,
  institutional_weight FLOAT DEFAULT 1.0,
  preferred_modality modality_type DEFAULT 'visual',
  xr_enabled BOOLEAN DEFAULT false,
  audio_enabled BOOLEAN DEFAULT true,
  haptic_enabled BOOLEAN DEFAULT false,
  onboarding_completed BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. TABLA DE ROLES
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  UNIQUE(user_id, role)
);

-- 4. SISTEMA TAMV CREDITS (Economía Ética)
CREATE TABLE public.tamv_credits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  balance DECIMAL(20, 2) DEFAULT 0.00,
  resonance_credits DECIMAL(20, 2) DEFAULT 0.00, -- Créditos por resonancia emocional
  lifetime_earnings DECIMAL(20, 2) DEFAULT 0.00,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. TRANSACCIONES
CREATE TABLE public.transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  type TEXT NOT NULL, -- deposit, withdrawal, transfer, reward, purchase
  amount DECIMAL(20, 2) NOT NULL,
  description TEXT,
  metadata JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. QUANTUM PETS
CREATE TABLE public.quantum_pets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  pet_type TEXT NOT NULL,
  level INTEGER DEFAULT 1,
  happiness FLOAT DEFAULT 75.0,
  energy FLOAT DEFAULT 100.0,
  health FLOAT DEFAULT 100.0,
  experience INTEGER DEFAULT 0,
  quantum_bond FLOAT DEFAULT 50.0,
  emotion emotion_type DEFAULT 'neutral',
  motto TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. DREAMSPACES (Espacios XR/4D)
CREATE TABLE public.dreamspaces (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  space_type TEXT, -- personal, collaborative, institutional, marketplace
  is_public BOOLEAN DEFAULT false,
  xr_config JSONB, -- Configuración 3D/4D
  assets JSONB, -- Assets XR asociados
  visitors INTEGER DEFAULT 0,
  rating FLOAT DEFAULT 0.0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. MARKETPLACE (Assets y NFTs)
CREATE TABLE public.marketplace_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  asset_type asset_type NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(20, 2) NOT NULL,
  image_url TEXT,
  metadata JSONB,
  is_auction BOOLEAN DEFAULT false,
  current_bid DECIMAL(20, 2),
  auction_ends_at TIMESTAMPTZ,
  sold BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. LOTERÍA TAMV
CREATE TABLE public.lottery_tickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  ticket_number TEXT UNIQUE NOT NULL,
  draw_id UUID, -- ID del sorteo
  is_winner BOOLEAN DEFAULT false,
  prize_amount DECIMAL(20, 2) DEFAULT 0.00,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. UNIVERSIDAD TAMV (Cursos y Progreso)
CREATE TABLE public.university_courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  instructor_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  category TEXT,
  level TEXT, -- beginner, intermediate, advanced, quantum
  duration_hours INTEGER,
  thumbnail_url TEXT,
  is_published BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE public.course_enrollments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  course_id UUID REFERENCES public.university_courses(id) ON DELETE CASCADE NOT NULL,
  progress FLOAT DEFAULT 0.0,
  completed BOOLEAN DEFAULT false,
  enrolled_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  UNIQUE(user_id, course_id)
);

-- 11. ISABELLA AI (Conversaciones y Memoria)
CREATE TABLE public.isabella_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title TEXT,
  emotion_analysis JSONB, -- Análisis emocional de la conversación
  consciousness_level FLOAT DEFAULT 0.5,
  empathy_score FLOAT DEFAULT 0.5,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE public.isabella_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID REFERENCES public.isabella_conversations(id) ON DELETE CASCADE NOT NULL,
  role TEXT NOT NULL, -- user, isabella, system
  content TEXT NOT NULL,
  emotion emotion_type,
  timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- 12. AUDIT TRAIL (Quantum Wiki y Auditoría)
CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id UUID,
  details JSONB,
  compliance_status compliance_level DEFAULT 'green',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 13. DIGITAL TWINS
CREATE TABLE public.digital_twins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  twin_type TEXT, -- personal, institutional, project
  simulation_data JSONB,
  evolution_history JSONB,
  consent_status BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 14. STREAMBOARDS (Posts sociales multisensoriales)
CREATE TABLE public.streamboard_posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  content TEXT NOT NULL,
  post_type TEXT DEFAULT 'text', -- text, image, video, audio, xr
  emotion emotion_type,
  media_urls TEXT[],
  likes INTEGER DEFAULT 0,
  comments INTEGER DEFAULT 0,
  shares INTEGER DEFAULT 0,
  is_public BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- FUNCIONES DE SEGURIDAD (Security Definer)
-- ============================================================================

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- Función para actualizar timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- TRIGGERS
-- ============================================================================

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_quantum_pets_updated_at BEFORE UPDATE ON public.quantum_pets
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_dreamspaces_updated_at BEFORE UPDATE ON public.dreamspaces
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_digital_twins_updated_at BEFORE UPDATE ON public.digital_twins
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_isabella_conversations_updated_at BEFORE UPDATE ON public.isabella_conversations
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================

-- Profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all profiles" ON public.profiles
FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users can update own profile" ON public.profiles
FOR UPDATE TO authenticated 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own profile" ON public.profiles
FOR INSERT TO authenticated 
WITH CHECK (auth.uid() = user_id);

-- User Roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view roles" ON public.user_roles
FOR SELECT TO authenticated USING (true);

CREATE POLICY "Only admins can insert roles" ON public.user_roles
FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- TAMV Credits
ALTER TABLE public.tamv_credits ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own credits" ON public.tamv_credits
FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can update own credits" ON public.tamv_credits
FOR UPDATE TO authenticated
USING (auth.uid() = user_id);

-- Transactions
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own transactions" ON public.transactions
FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own transactions" ON public.transactions
FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

-- Quantum Pets
ALTER TABLE public.quantum_pets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own pets" ON public.quantum_pets
FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can manage own pets" ON public.quantum_pets
FOR ALL TO authenticated
USING (auth.uid() = user_id);

-- DreamSpaces
ALTER TABLE public.dreamspaces ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view public dreamspaces" ON public.dreamspaces
FOR SELECT TO authenticated
USING (is_public = true OR auth.uid() = user_id);

CREATE POLICY "Users can manage own dreamspaces" ON public.dreamspaces
FOR ALL TO authenticated
USING (auth.uid() = user_id);

-- Marketplace
ALTER TABLE public.marketplace_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view marketplace items" ON public.marketplace_items
FOR SELECT TO authenticated USING (true);

CREATE POLICY "Users can manage own items" ON public.marketplace_items
FOR ALL TO authenticated
USING (auth.uid() = seller_id);

-- Lottery
ALTER TABLE public.lottery_tickets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own tickets" ON public.lottery_tickets
FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can create tickets" ON public.lottery_tickets
FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

-- University
ALTER TABLE public.university_courses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view published courses" ON public.university_courses
FOR SELECT TO authenticated USING (is_published = true OR auth.uid() = instructor_id);

CREATE POLICY "Instructors can manage own courses" ON public.university_courses
FOR ALL TO authenticated
USING (auth.uid() = instructor_id);

ALTER TABLE public.course_enrollments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own enrollments" ON public.course_enrollments
FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can manage own enrollments" ON public.course_enrollments
FOR ALL TO authenticated
USING (auth.uid() = user_id);

-- Isabella AI
ALTER TABLE public.isabella_conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own conversations" ON public.isabella_conversations
FOR ALL TO authenticated
USING (auth.uid() = user_id);

ALTER TABLE public.isabella_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view messages in own conversations" ON public.isabella_messages
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.isabella_conversations
    WHERE id = conversation_id AND user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert messages in own conversations" ON public.isabella_messages
FOR INSERT TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.isabella_conversations
    WHERE id = conversation_id AND user_id = auth.uid()
  )
);

-- Audit Logs
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own audit logs" ON public.audit_logs
FOR SELECT TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "System can insert audit logs" ON public.audit_logs
FOR INSERT TO authenticated
WITH CHECK (true);

-- Digital Twins
ALTER TABLE public.digital_twins ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own twins" ON public.digital_twins
FOR ALL TO authenticated
USING (auth.uid() = user_id);

-- Streamboard
ALTER TABLE public.streamboard_posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view public posts" ON public.streamboard_posts
FOR SELECT TO authenticated
USING (is_public = true OR auth.uid() = user_id);

CREATE POLICY "Users can manage own posts" ON public.streamboard_posts
FOR ALL TO authenticated
USING (auth.uid() = user_id);

-- ============================================================================
-- INDICES PARA PERFORMANCE
-- ============================================================================

CREATE INDEX idx_profiles_user_id ON public.profiles(user_id);
CREATE INDEX idx_profiles_id_nvida ON public.profiles(id_nvida);
CREATE INDEX idx_user_roles_user_id ON public.user_roles(user_id);
CREATE INDEX idx_tamv_credits_user_id ON public.tamv_credits(user_id);
CREATE INDEX idx_transactions_user_id ON public.transactions(user_id);
CREATE INDEX idx_quantum_pets_user_id ON public.quantum_pets(user_id);
CREATE INDEX idx_dreamspaces_user_id ON public.dreamspaces(user_id);
CREATE INDEX idx_marketplace_seller_id ON public.marketplace_items(seller_id);
CREATE INDEX idx_lottery_user_id ON public.lottery_tickets(user_id);
CREATE INDEX idx_course_enrollments_user_id ON public.course_enrollments(user_id);
CREATE INDEX idx_isabella_conversations_user_id ON public.isabella_conversations(user_id);
CREATE INDEX idx_isabella_messages_conversation_id ON public.isabella_messages(conversation_id);
CREATE INDEX idx_audit_logs_user_id ON public.audit_logs(user_id);
CREATE INDEX idx_digital_twins_user_id ON public.digital_twins(user_id);
CREATE INDEX idx_streamboard_posts_user_id ON public.streamboard_posts(user_id);