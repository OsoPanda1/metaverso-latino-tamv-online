-- Enable realtime for quantum_pets
ALTER PUBLICATION supabase_realtime ADD TABLE public.quantum_pets;

-- Create marketplace_purchases table for tracking transactions
CREATE TABLE IF NOT EXISTS public.marketplace_purchases (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  buyer_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  item_id uuid NOT NULL REFERENCES public.marketplace_items(id) ON DELETE CASCADE,
  purchase_price numeric NOT NULL,
  purchased_at timestamp with time zone NOT NULL DEFAULT now(),
  status text NOT NULL DEFAULT 'completed'
);

ALTER TABLE public.marketplace_purchases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own purchases"
ON public.marketplace_purchases
FOR SELECT
USING (auth.uid() = buyer_id);

CREATE POLICY "Users can create purchases"
ON public.marketplace_purchases
FOR INSERT
WITH CHECK (auth.uid() = buyer_id);

-- Enable realtime for marketplace
ALTER PUBLICATION supabase_realtime ADD TABLE public.marketplace_items;
ALTER PUBLICATION supabase_realtime ADD TABLE public.marketplace_purchases;

-- Enable realtime for bank transactions
ALTER PUBLICATION supabase_realtime ADD TABLE public.transactions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.tamv_credits;