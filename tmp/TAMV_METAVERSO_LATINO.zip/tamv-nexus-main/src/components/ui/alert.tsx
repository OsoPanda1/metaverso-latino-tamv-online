import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

/**
 * alertVariants — clases Quantum para visual premium/dashboard federado
 * Incluye variantes para modo destructivo, info, quantum, custom.
 */
const alertVariants = cva(
  "relative w-full rounded-lg border p-4 shadow-md transition-colors duration-200 aria-live-polite focus:outline-none [&>svg~*]:pl-7 [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground",
  {
    variants: {
      variant: {
        default: "bg-background text-foreground border-quantum/50",
        destructive: "border-destructive/50 text-destructive dark:border-destructive/80 bg-destructive/10 [&>svg]:text-destructive",
        quantum: "border-quantum bg-gradient-to-br from-quantum/10 to-xr/7 text-quantum shadow-quantum [&>svg]:text-quantum",
        info: "border-blue-400 bg-blue-50 text-blue-900 [&>svg]:text-blue-600",
        success: "border-green-400 bg-green-50 text-green-900 [&>svg]:text-green-600",
        warning: "border-yellow-400 bg-yellow-50 text-yellow-900 [&>svg]:text-yellow-600",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
);

/**
 * Alert Quantum — bloque auditable, visual avanzado, IA-ready.
 * Props: 
 * - variant: quantum, destructive, info, success, warning, default
 * - auditTrail: tracking de auditoría federada
 * - logs: integración IA/logs dentro del alert
 * - icon: visual custom/icono IA
 */
const Alert = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> &
    VariantProps<typeof alertVariants> & {
      auditTrail?: string;
      logs?: React.ReactNode;
      icon?: React.ReactNode;
    }
>(({ className, variant, auditTrail, logs, icon, ...props }, ref) => (
  <div
    ref={ref}
    role="alert"
    aria-live="polite"
    className={cn(alertVariants({ variant }), className)}
    data-audit-trail={auditTrail}
    {...props}
  >
    {icon ? <span className="absolute left-4 top-4">{icon}</span> : null}
    {props.children}
    {logs && (
      <div className="mt-2 px-2 py-1 bg-quantum/5 text-xs font-mono text-quantum/80 border-l-2 border-quantum rounded-bl-lg">
        <span>QuantumLog:</span> {logs}
      </div>
    )}
  </div>
));
Alert.displayName = "Alert";

/**
 * AlertTitle — encabezado visual, accesible, permite custom icon IA
 */
const AlertTitle = React.forwardRef<
  HTMLHeadingElement,
  React.HTMLAttributes<HTMLHeadingElement>
>(({ className, ...props }, ref) => (
  <h5
    ref={ref}
    className={cn("mb-1 font-medium leading-none tracking-tight text-quantum", className)}
    {...props}
  />
));
AlertTitle.displayName = "AlertTitle";

/**
 * AlertDescription — área explicativa, multiparada, IA integration
 */
const AlertDescription = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("text-sm [&_p]:leading-relaxed", className)} {...props} />
));
AlertDescription.displayName = "AlertDescription";

export { Alert, AlertTitle, AlertDescription };

/**
 * ========== EJEMPLO DE USO QUANTUM ==========
 * <Alert variant="quantum" auditTrail="user-login-2025-11-21" logs="Validado por Isabella AI" icon={<QuantumIcon />}>
 *   <AlertTitle>¡Transacción exitosa Quantum!</AlertTitle>
 *   <AlertDescription>
 *     Tu operación fue validada por IA federada y auditada en multi-nodo XR.
 *     <p>Consulta el log para detalles y federación global.</p>
 *   </AlertDescription>
 * </Alert>
 */

