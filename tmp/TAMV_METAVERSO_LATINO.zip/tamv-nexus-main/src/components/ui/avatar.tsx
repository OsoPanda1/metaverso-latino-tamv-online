// components/ui/Avatar.tsx
import * as React from "react";
import * as AvatarPrimitive from "@radix-ui/react-avatar";
import { cn } from "@/lib/utils";

/**
 * Avatar TAMV Supra-Flagship:
 * - Soporta variantes visuales: quantum, dashboard, classic, ghost
 * - auditTrail: registro para auditoría (logs, tracing, federación IA)
 * - status: activo, ausente, error (para multiusuario, dashboards)
 * - Flexibilidad máxima (ref forwarding, custom class, gestión fallback)
 */

interface AvatarProps
  extends React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Root> {
  auditTrail?: string;
  variant?: "default" | "quantum" | "dashboard" | "ghost";
  status?: "active" | "idle" | "error";
  className?: string;
}

const Avatar = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Root>,
  AvatarProps
>(({ className, auditTrail, variant = "default", status, ...props }, ref) => (
  <AvatarPrimitive.Root
    ref={ref}
    className={cn(
      "relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full shadow-md",
      variant === "quantum" && "ring-2 ring-quantum/80 bg-gradient-to-br from-quantum/20 to-xr/20",
      variant === "dashboard" && "ring-2 ring-primary/70",
      variant === "ghost" && "opacity-60 bg-muted",
      status === "active" && "border-2 border-green-400",
      status === "idle" && "border-2 border-yellow-400",
      status === "error" && "border-2 border-destructive animate-pulse",
      className
    )}
    data-audit-trail={auditTrail}
    data-avatar-status={status}
    {...props}
  />
));
Avatar.displayName = "AvatarTAMV";

const AvatarImage = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Image>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Image>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Image
    ref={ref}
    className={cn("aspect-square h-full w-full object-cover object-center", className)}
    {...props}
  />
));
AvatarImage.displayName = "AvatarTAMVImage";

const AvatarFallback = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Fallback>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Fallback> & {
    icon?: React.ReactNode;
    fallbackLabel?: string;
  }
>(({ className, icon, fallbackLabel, ...props }, ref) => (
  <AvatarPrimitive.Fallback
    ref={ref}
    className={cn(
      "flex h-full w-full items-center justify-center rounded-full bg-muted text-center select-none font-semibold",
      className
    )}
    {...props}
  >
    {icon ?? fallbackLabel ?? "?"}
  </AvatarPrimitive.Fallback>
));
AvatarFallback.displayName = "AvatarTAMVFallback";

// Exporta el paquete flagship
export { Avatar, AvatarImage, AvatarFallback };

/*
USO AVANZADO EJEMPLO:
<Avatar variant="quantum" auditTrail="user-avatar-20251121" status="active">
  <AvatarImage src={user.imgUrl} alt={user.name} />
  <AvatarFallback fallbackLabel={user.initials} />
</Avatar>
*/

