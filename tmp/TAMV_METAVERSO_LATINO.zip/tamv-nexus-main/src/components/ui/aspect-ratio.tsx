// components/ui/AspectRatio.tsx
import * as React from "react";
import * as AspectRatioPrimitive from "@radix-ui/react-aspect-ratio";

/**
 * AspectRatio TAMV — componente premium con soporte para:
 * - auditTrail: tracking visual/auditoría federada
 * - className: customización visual quantum/XR
 * - variant: para ampliar con estilos visuales (ejemplo: quantum, dashboard)
 * - Ref forwarding para máxima integración y testabilidad
 */

interface AspectRatioProps
  extends React.ComponentPropsWithoutRef<typeof AspectRatioPrimitive.Root> {
  auditTrail?: string;
  variant?: "default" | "quantum" | "dashboard";
  className?: string;
}

const AspectRatio = React.forwardRef<
  React.ElementRef<typeof AspectRatioPrimitive.Root>,
  AspectRatioProps
>(({ children, auditTrail, className, variant = "default", ...props }, ref) => (
  <AspectRatioPrimitive.Root
    ref={ref}
    className={[
      className,
      variant === "quantum"
        ? "border-quantum bg-gradient-to-br from-quantum/10 to-xr/5"
        : variant === "dashboard"
        ? "border-dashed border-primary/40 bg-card"
        : "",
    ].join(" ")}
    data-audit-trail={auditTrail}
    {...props}
  >
    {children}
  </AspectRatioPrimitive.Root>
));
AspectRatio.displayName = "AspectRatio";

export { AspectRatio };

/*
  USO EJEMPLO:
  <AspectRatio ratio={16 / 9} variant="quantum" auditTrail="display-hero-tamv">
    <img src="/assets/hero-tamv.png" alt="Hero Quantum TAMV" className="object-cover rounded-xl" />
  </AspectRatio>
*/

