import * as React from "react";
import * as AlertDialogPrimitive from "@radix-ui/react-alert-dialog";
import { cn } from "@/lib/utils";
import { buttonVariants } from "@/components/ui/button";

/**
 * AlertDialog Quantum XR — diálogo seguro, auditable, integrable con IA y auditoría federada.
 * Props globales de contexto, tracking y auditoría listos para producción TAMV.
 */
const AlertDialog = AlertDialogPrimitive.Root;

// Trigger universal, permite IA-control, tracking, custom roles
const AlertDialogTrigger = AlertDialogPrimitive.Trigger;

// Portal seguro, encapsulable en DreamSpaces globales
const AlertDialogPortal = AlertDialogPrimitive.Portal;

/**
 * Overlay Quantum: animado, accesible, ideal para contexto XR/IA
 * Admite: auditTrail (tracking único IA/auditoría), extensibilidad visual
 */
const AlertDialogOverlay = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Overlay> & { auditTrail?: string }
>(({ className, auditTrail, ...props }, ref) => (
  <AlertDialogPrimitive.Overlay
    ref={ref}
    className={cn(
      "fixed inset-0 z-50 bg-black/80 backdrop-blur-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    )}
    data-audit-trail={auditTrail}
    aria-hidden="true"
    {...props}
  />
));
AlertDialogOverlay.displayName = "AlertDialogOverlay";

/**
 * Content Quantum: accesible, visual XR, auditable. Extensible con logs IA
 */
const AlertDialogContent = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Content> & {
    auditTrail?: string;
    logs?: React.ReactNode;
    theme?: "default" | "quantum" | "ghost";
  }
>(({ className, auditTrail, logs, theme = "default", ...props }, ref) => (
  <AlertDialogPortal>
    <AlertDialogOverlay auditTrail={auditTrail} />
    <AlertDialogPrimitive.Content
      ref={ref}
      className={cn(
        "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 sm:rounded-lg",
        theme === "quantum" && "bg-gradient-to-br from-quantum/10 via-white/70 to-xr/10 border-quantum shadow-quantum",
        theme === "ghost" && "bg-transparent border-none shadow-none text-neutral-500",
        className
      )}
      data-audit-trail={auditTrail}
      role="alertdialog"
      aria-modal="true"
      {...props}
    >
      {props.children}
      {logs && (
        <div className="mt-2 px-3 py-2 bg-quantum/10 text-xs font-mono text-quantum border-l-2 border-quantum/60 rounded-bl-lg">
          <span>QuantumLog:</span> {logs}
        </div>
      )}
    </AlertDialogPrimitive.Content>
  </AlertDialogPortal>
));
AlertDialogContent.displayName = "AlertDialogContent";

/**
 * Header visual premium, multi-theme, accesible
 */
const AlertDialogHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("flex flex-col space-y-2 text-center sm:text-left", className)} {...props} />
);
AlertDialogHeader.displayName = "AlertDialogHeader";

/**
 * Footer sofisticado, control contextual federado
 */
const AlertDialogFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className)} {...props} />
);
AlertDialogFooter.displayName = "AlertDialogFooter";

// Título accesible, tema Quantum opcional
const AlertDialogTitle = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Title>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Title
    ref={ref}
    className={cn("text-lg font-semibold text-quantum", className)}
    {...props}
  />
));
AlertDialogTitle.displayName = "AlertDialogTitle";

// Descripción accesible, integrado contexto IA
const AlertDialogDescription = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Description>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Description
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
));
AlertDialogDescription.displayName = "AlertDialogDescription";

// Acción Quantum, logging, IA, seguridad reforzada
const AlertDialogAction = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Action>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Action> & { auditTrail?: string }
>(({ className, auditTrail, ...props }, ref) => (
  <AlertDialogPrimitive.Action
    ref={ref}
    className={cn(buttonVariants(), "bg-quantum text-white", className)}
    data-audit-trail={auditTrail}
    {...props}
  />
));
AlertDialogAction.displayName = "AlertDialogAction";

// Cancel/outlet, control IA y logs
const AlertDialogCancel = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Cancel>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Cancel> & { auditTrail?: string }
>(({ className, auditTrail, ...props }, ref) => (
  <AlertDialogPrimitive.Cancel
    ref={ref}
    className={cn(buttonVariants({ variant: "outline" }), "mt-2 sm:mt-0 bg-white text-quantum border-quantum", className)}
    data-audit-trail={auditTrail}
    {...props}
  />
));
AlertDialogCancel.displayName = "AlertDialogCancel";

// Exporta todo el bloque Quantum, IA, audit-ready
export {
  AlertDialog,
  AlertDialogPortal,
  AlertDialogOverlay,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
};

/**
 * ============= EJEMPLO DE USO QUANTUM DASHBOARD =============
 * <AlertDialog>
 *   <AlertDialogTrigger>
 *     Abrir alerta auditada
 *   </AlertDialogTrigger>
 *   <AlertDialogContent theme="quantum" auditTrail="login-2025-11-21" logs="triggered by Isabella">
 *     <AlertDialogHeader>
 *       <AlertDialogTitle>¡Warning Quantum!</AlertDialogTitle>
 *       <AlertDialogDescription>Esta acción requiere auditoría federada y validación IA.</AlertDialogDescription>
 *     </AlertDialogHeader>
 *     <AlertDialogFooter>
 *       <AlertDialogCancel auditTrail="cancel-2025-11-21">Cancelar</AlertDialogCancel>
 *       <AlertDialogAction auditTrail="confirm-2025-11-21">Confirmar</AlertDialogAction>
 *     </AlertDialogFooter>
 *   </AlertDialogContent>
 * </AlertDialog>
 */
