import * as React from "react";
import * as AccordionPrimitive from "@radix-ui/react-accordion";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * AccordionRoot: El núcleo del acordeón Quantum, altamente flexible.
 * Admite multi/single, collapsible, y props extendidos (para integración IA/contenido dinámico).
 */
const Accordion = AccordionPrimitive.Root;

/**
 * AccordionItem: Componente robusto, incluye:
 * - debug: visual testing
 * - auditTrail: para tracing y logs de auditoría federada
 * - id prop para tracking o auditoría IA
 */
const AccordionItem = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Item> & {
    debug?: boolean;
    auditTrail?: string;
    id?: string;
  }
>(({ className, debug = false, auditTrail, id, ...props }, ref) => (
  <AccordionPrimitive.Item
    ref={ref}
    id={id}
    className={cn(
      "border-b border-quantum/60 bg-white dark:bg-black transition-colors duration-200 focus-within:ring-quantum/60 shadow-sm",
      debug && "bg-red-100 animate-pulse",
      className
    )}
    data-debug={debug ? "enabled" : undefined}
    data-audit-trail={auditTrail}
    aria-labelledby={props.value ? `accordion-item-${props.value}` : undefined}
    {...props}
  />
));
AccordionItem.displayName = "AccordionItem";

/**
 * AccordionTrigger: Botón accesible y visual, IA-ready, variantes quantum.
 * - aiProps: para integración IA/contexto externo
 * - variant: permite quantum, warning, primary, custom
 */
const AccordionTrigger = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Trigger> & {
    aiProps?: { [key: string]: any };
    variant?: "primary" | "quantum" | "warning";
  }
>(({ className, children, aiProps, variant = "primary", ...props }, ref) => (
  <AccordionPrimitive.Header
    className={cn("flex items-center", aiProps?.headerClass)}
    role="heading"
    aria-level={aiProps?.ariaLevel ?? 3}
  >
    <AccordionPrimitive.Trigger
      ref={ref}
      className={cn(
        "flex flex-1 items-center justify-between py-4 font-bold transition-all hover:underline focus:outline-none focus:ring-2 focus:ring-quantum",
        "[&[data-state=open]>svg]:rotate-180",
        variant === "quantum" && "text-quantum bg-gradient-to-r from-quantum/5 to-xr/5",
        variant === "warning" && "text-red-600 bg-red-50",
        className,
        aiProps?.triggerClass
      )}
      {...props}
      aria-controls={props["aria-controls"]}
    >
      {children}
      <ChevronDown className="h-4 w-4 shrink-0 transition-transform duration-200" />
    </AccordionPrimitive.Trigger>
  </AccordionPrimitive.Header>
));
AccordionTrigger.displayName = "AccordionTrigger";

/**
 * AccordionContent: Área expandida, visual quantum, con:
 * - auditTrail: registro para tracing IA/logs federados
 * - theme: "default", "quantum", "ghost"
 * - logs: bloque especial para reportes AI/interacción
 */
const AccordionContent = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Content> & {
    auditTrail?: string;
    theme?: "default" | "quantum" | "ghost";
    logs?: React.ReactNode;
  }
>(({ className, children, auditTrail, theme = "default", logs, ...props }, ref) => (
  <AccordionPrimitive.Content
    ref={ref}
    className={cn(
      "overflow-hidden text-sm transition-all data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
      theme === "quantum" &&
        "bg-gradient-to-br from-quantum/10 via-white/50 to-xr/10 text-quantum",
      theme === "ghost" && "bg-transparent text-neutral-500",
      className
    )}
    {...props}
    aria-live="polite"
    data-audit-trail={auditTrail}
  >
    <div className={cn("pb-4 pt-0", className)}>
      {children}
      {logs && (
        <div className="border-l-4 border-quantum/70 pl-3 mt-2 text-xs text-quantum/80 font-mono bg-quantum/5">
          <span>Quantum Log:</span> {logs}
        </div>
      )}
    </div>
  </AccordionPrimitive.Content>
));
AccordionContent.displayName = "AccordionContent";

export { Accordion, AccordionItem, AccordionTrigger, AccordionContent };

/**
 * =============== EJEMPLO DE USO AVANZADO TAMV Quantum ===============
 * <Accordion type="multiple" defaultValue={['item1']}>
 *   <AccordionItem value="item1" id="audit-section" auditTrail="login-2025-11-21">
 *     <AccordionTrigger variant="quantum" aiProps={{ ariaLevel: 2 }}>
 *       Seguridad avanzada y federación
 *     </AccordionTrigger>
 *     <AccordionContent theme="quantum" logs="Audit trail activo por Isabella AI">
 *       Información crítica de seguridad, IA, federación, logs y reporte quantum.
 *     </AccordionContent>
 *   </AccordionItem>
 *   <AccordionItem value="item2">
 *     <AccordionTrigger>Principal</AccordionTrigger>
 *     <AccordionContent>
 *       Contenido clásico, configurable para onboarding o paneles XR.
 *     </AccordionContent>
 *   </AccordionItem>
 * </Accordion>
 */

