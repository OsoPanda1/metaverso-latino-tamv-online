// components/ui/Badge.tsx
import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

/**
 * Badge TAMV Quantum Flagship:
 * - Variantes visuales: quantum, dashboard, secondary, destructive, outline
 * - Props auditTrail, status, tag, label para auditoría y dashboards IA
 * - Accesibilidad, integración XR/microservicio, expansibilidad
 */

const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-quantum/70 focus:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
        quantum: "border-quantum bg-gradient-to-r from-quantum/10 to-xr/10 text-quantum shadow-quantum/30",
        dashboard: "border-primary/50 bg-card text-primary font-bold",
        secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
        destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
        outline: "border border-quantum text-foreground bg-white",
        ghost: "border-none bg-transparent text-muted-foreground",
      },
      status: {
        active: "ring-2 ring-green-400",
        idle: "ring-2 ring-yellow-400",
        error: "ring-2 ring-destructive/80",
      }
    },
    defaultVariants: {
      variant: "default",
      status: undefined,
    }
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {
  auditTrail?: string;
  tag?: string;
  label?: string;
  status?: "active" | "idle" | "error";
}

function Badge({ className, variant, status, auditTrail, tag, label, children, ...props }: BadgeProps) {
  return (
    <div
      className={cn(badgeVariants({ variant, status }), className)}
      data-audit-trail={auditTrail}
      data-badge-tag={tag}
      data-badge-status={status}
      tabIndex={0}
      aria-label={label ?? tag ?? undefined}
      {...props}
    >
      {children ?? label ?? tag}
    </div>
  );
}

export { Badge, badgeVariants };

/*
USO AVANZADO:
<Badge variant="quantum" status="active" auditTrail="status-badge-20251121" tag="QuantumXR" label="XR Quantum" />
<Badge variant="destructive" status="error" label="¡Error de IA!" />
*/

// TAMV Flagship UI Components Integration

// AspectRatio.tsx
import * as React from "react";
import * as AspectRatioPrimitive from "@radix-ui/react-aspect-ratio";

interface AspectRatioProps
  extends React.ComponentPropsWithoutRef<typeof AspectRatioPrimitive.Root> {
  auditTrail?: string;
  variant?: "default" | "quantum" | "dashboard";
  className?: string;
}

const AspectRatio = React.forwardRef<
  React.ElementRef<typeof AspectRatioPrimitive.Root>,
  AspectRatioProps
>(({ children, auditTrail, className, variant = "default", ...props }, ref) => (
  <AspectRatioPrimitive.Root
    ref={ref}
    className={[
      className,
      variant === "quantum"
        ? "border-quantum bg-gradient-to-br from-quantum/10 to-xr/5"
        : variant === "dashboard"
        ? "border-dashed border-primary/40 bg-card"
        : "",
    ].join(" ")}
    data-audit-trail={auditTrail}
    {...props}
  >
    {children}
  </AspectRatioPrimitive.Root>
));
AspectRatio.displayName = "AspectRatio";

export { AspectRatio };


// Avatar.tsx
import * as AvatarPrimitive from "@radix-ui/react-avatar";
import { cn } from "@/lib/utils";

interface AvatarProps
  extends React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Root> {
  auditTrail?: string;
  variant?: "default" | "quantum" | "dashboard" | "ghost";
  status?: "active" | "idle" | "error";
  className?: string;
}

const Avatar = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Root>,
  AvatarProps
>(({ className, auditTrail, variant = "default", status, ...props }, ref) => (
  <AvatarPrimitive.Root
    ref={ref}
    className={cn(
      "relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full shadow-md",
      variant === "quantum" && "ring-2 ring-quantum/80 bg-gradient-to-br from-quantum/20 to-xr/20",
      variant === "dashboard" && "ring-2 ring-primary/70",
      variant === "ghost" && "opacity-60 bg-muted",
      status === "active" && "border-2 border-green-400",
      status === "idle" && "border-2 border-yellow-400",
      status === "error" && "border-2 border-destructive animate-pulse",
      className
    )}
    data-audit-trail={auditTrail}
    data-avatar-status={status}
    {...props}
  />
));
Avatar.displayName = "AvatarTAMV";

const AvatarImage = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Image>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Image>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Image
    ref={ref}
    className={cn("aspect-square h-full w-full object-cover object-center", className)}
    {...props}
  />
));
AvatarImage.displayName = "AvatarTAMVImage";

const AvatarFallback = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Fallback>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Fallback> & {
    icon?: React.ReactNode;
    fallbackLabel?: string;
  }
>(({ className, icon, fallbackLabel, ...props }, ref) => (
  <AvatarPrimitive.Fallback
    ref={ref}
    className={cn(
      "flex h-full w-full items-center justify-center rounded-full bg-muted text-center select-none font-semibold",
      className
    )}
    {...props}
  >
    {icon ?? fallbackLabel ?? "?"}
  </AvatarPrimitive.Fallback>
));
AvatarFallback.displayName = "AvatarTAMVFallback";

export { Avatar, AvatarImage, AvatarFallback };


// Badge.tsx
import { cva, type VariantProps } from "class-variance-authority";

const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-quantum/70 focus:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
        quantum: "border-quantum bg-gradient-to-r from-quantum/10 to-xr/10 text-quantum shadow-quantum/30",
        dashboard: "border-primary/50 bg-card text-primary font-bold",
        secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
        destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
        outline: "border border-quantum text-foreground bg-white",
        ghost: "border-none bg-transparent text-muted-foreground",
      },
      status: {
        active: "ring-2 ring-green-400",
        idle: "ring-2 ring-yellow-400",
        error: "ring-2 ring-destructive/80",
      }
    },
    defaultVariants: {
      variant: "default",
      status: undefined,
    }
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {
  auditTrail?: string;
  tag?: string;
  label?: string;
  status?: "active" | "idle" | "error";
}

function Badge({ className, variant, status, auditTrail, tag, label, children, ...props }: BadgeProps) {
  return (
    <div
      className={cn(badgeVariants({ variant, status }), className)}
      data-audit-trail={auditTrail}
      data-badge-tag={tag}
      data-badge-status={status}
      tabIndex={0}
      aria-label={label ?? tag ?? undefined}
      {...props}
    >
      {children ?? label ?? tag}
    </div>
  );
}

export { Badge, badgeVariants };

/*
EJEMPLOS DE USO EN EL ECOSISTEMA TAMV:

// AspectRatio
<AspectRatio ratio={16/9} variant="quantum" auditTrail="hero-img-tamv">
  <img src="/assets/hero-tamv.png" alt="Quantum Hero" />
</AspectRatio>

// Avatar
<Avatar variant="quantum" status="active" auditTrail="avatar-user-20251121">
  <AvatarImage src={user.imgUrl} alt={user.name} />
  <AvatarFallback fallbackLabel={user.initials} />
</Avatar>

// Badge
<Badge variant="quantum" status="active" tag="QuantumXR" label="XR Quantum" />
<Badge variant="destructive" status="error" label="¡Error IA!" />
*/

