import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Brain, 
  GraduationCap, 
  Palette, 
  Microscope, 
  Lightbulb,
  Users,
  Globe,
  Rocket,
  ChevronRight
} from "lucide-react";

const ecosystemSections = [
  { icon: Brain, label: "IA & Tecnología", color: "text-primary" },
  { icon: GraduationCap, label: "Educación", color: "text-secondary" },
  { icon: Palette, label: "Arte & Cultura", color: "text-accent" },
  { icon: Microscope, label: "Ciencia", color: "text-quantum" },
  { icon: Lightbulb, label: "Innovación", color: "text-biometric" },
  { icon: Users, label: "Comunidad", color: "text-neural" },
  { icon: Globe, label: "Global", color: "text-primary" },
  { icon: Rocket, label: "Proyectos", color: "text-secondary" },
];

interface EcosystemSidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

export const EcosystemSidebar = ({ isOpen, onToggle }: EcosystemSidebarProps) => {
  return (
    <>
      {/* Toggle button */}
      <Button
        variant="ghost"
        size="icon"
        className={`fixed top-24 ${isOpen ? 'right-80' : 'right-4'} z-40 glass border border-primary/30 hover:border-primary/50 transition-all duration-300`}
        onClick={onToggle}
      >
        <ChevronRight className={`w-5 h-5 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </Button>

      {/* Sidebar */}
      <div
        className={`fixed top-20 right-0 h-[calc(100vh-5rem)] w-72 glass-strong border-l border-primary/30 z-30 transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="p-6">
          <h2 className="text-2xl font-bold text-holographic mb-6">
            Ecosistema TAMV
          </h2>
          
          <ScrollArea className="h-[calc(100vh-12rem)]">
            <div className="space-y-2">
              {ecosystemSections.map((section) => {
                const Icon = section.icon;
                return (
                  <Button
                    key={section.label}
                    variant="ghost"
                    className="w-full justify-start gap-3 hover:bg-primary/10 group"
                  >
                    <Icon className={`w-5 h-5 ${section.color} group-hover:scale-110 transition-transform`} />
                    <span className="text-foreground group-hover:text-primary transition-colors">
                      {section.label}
                    </span>
                  </Button>
                );
              })}
            </div>

            <div className="mt-8 glass rounded-xl p-4 border border-primary/20">
              <h3 className="font-semibold mb-3 text-primary">
                Constelaciones Activas
              </h3>
              <div className="space-y-2">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <div className="w-2 h-2 rounded-full bg-biometric pulse-glow" />
                    <span className="text-muted-foreground">Constelación {i}</span>
                  </div>
                ))}
              </div>
            </div>
          </ScrollArea>
        </div>
      </div>
    </>
  );
};
