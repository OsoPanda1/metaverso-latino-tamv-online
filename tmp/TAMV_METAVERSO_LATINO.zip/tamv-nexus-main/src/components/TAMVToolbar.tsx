import { Button } from "@/components/ui/button";
import { Home, Compass, User, Settings } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface TAMVToolbarProps {
  onFollow?: () => void;
  isFollowing?: boolean;
  likes?: number;
  comments?: number;
  onLike?: () => void;
  onComment?: () => void;
  onTip?: () => void;
  onDonate?: () => void;
  onMembership?: () => void;
}

export const TAMVToolbar = ({
  onFollow,
  isFollowing = false,
  likes = 0,
  comments = 0,
  onLike,
  onComment,
  onTip,
  onDonate,
  onMembership,
}: TAMVToolbarProps) => {
  const navigate = useNavigate();

  return (
    <div className="fixed top-0 left-0 right-0 z-50 glass-strong border-b border-primary/30">
      <div className="container mx-auto px-6 py-3">
        <div className="flex items-center justify-between">
          {/* Logo y navegación principal */}
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-holographic rounded-lg pulse-glow" />
              <span className="text-xl font-bold text-holographic">TAMV</span>
            </div>
            
            <Button 
              variant="ghost" 
              className="gap-2 hover:bg-primary/10 hover:text-primary transition-all"
              onClick={() => navigate("/")}
            >
              <Home className="w-4 h-4" />
              <span className="hidden md:inline">Muro Global</span>
            </Button>
            
            <Button 
              variant="ghost"
              className="gap-2 hover:bg-secondary/10 hover:text-secondary transition-all"
              onClick={() => navigate("/ecosystem")}
            >
              <Compass className="w-4 h-4" />
              <span className="hidden md:inline">Ecosistema</span>
            </Button>
          </div>

          {/* Acciones del perfil */}
          <div className="flex items-center gap-2">
            <Button
              variant={isFollowing ? "outline" : "default"}
              className={
                isFollowing
                  ? "border-primary text-primary hover:bg-primary/10"
                  : "bg-gradient-primary border-0 hover:shadow-glow-primary"
              }
              onClick={onFollow}
            >
              {isFollowing ? "Siguiendo" : "Seguir"}
            </Button>

            <Button
              variant="ghost"
              className="gap-2 hover:bg-accent/10 hover:text-accent transition-all"
              onClick={onLike}
            >
              ❤️ <span className="hidden sm:inline">{likes}</span>
            </Button>

            <Button
              variant="ghost"
              className="gap-2 hover:bg-quantum/10 hover:text-quantum transition-all"
              onClick={onComment}
            >
              💬 <span className="hidden sm:inline">{comments}</span>
            </Button>

            <Button
              variant="ghost"
              className="hover:bg-biometric/10 hover:text-biometric transition-all"
              onClick={onTip}
            >
              💸 <span className="hidden md:inline">Propina</span>
            </Button>

            <Button
              variant="ghost"
              className="hover:bg-secondary/10 hover:text-secondary transition-all"
              onClick={onDonate}
            >
              🎁 <span className="hidden md:inline">Donar</span>
            </Button>

            <Button
              variant="ghost"
              className="hover:bg-neural/10 hover:text-neural transition-all"
              onClick={onMembership}
            >
              🛡️ <span className="hidden md:inline">Membresía</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
