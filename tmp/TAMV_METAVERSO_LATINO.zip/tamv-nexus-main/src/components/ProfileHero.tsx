import { Badge } from "@/components/ui/badge";
import { MapPin, Zap, Coins, Star } from "lucide-react";

interface ProfileHeroProps {
  avatar?: string;
  name: string;
  username: string;
  bio: string;
  location?: string;
  level: number;
  resonance: number;
  credits: number;
  achievements?: number;
}

export const ProfileHero = ({
  avatar = "https://api.dicebear.com/7.x/avataaars/svg?seed=tamv",
  name,
  username,
  bio,
  location,
  level,
  resonance,
  credits,
  achievements = 0,
}: ProfileHeroProps) => {
  return (
    <div className="relative">
      {/* Banner holográfico */}
      <div className="h-64 bg-gradient-holographic relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-30" />
      </div>

      {/* Contenedor del perfil */}
      <div className="container mx-auto px-6">
        <div className="relative -mt-24">
          <div className="glass-strong rounded-2xl p-8 shadow-elegant">
            <div className="flex flex-col md:flex-row gap-8">
              {/* Avatar */}
              <div className="relative">
                <div className="w-32 h-32 rounded-2xl overflow-hidden ring-4 ring-primary/50 shadow-glow-primary">
                  <img
                    src={avatar}
                    alt={name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <Badge className="absolute -bottom-2 -right-2 bg-gradient-primary border-0 shadow-glow-primary">
                  LVL {level}
                </Badge>
              </div>

              {/* Info principal */}
              <div className="flex-1 space-y-4">
                <div>
                  <h1 className="text-4xl font-bold text-holographic mb-2">
                    {name}
                  </h1>
                  <p className="text-muted-foreground text-lg">@{username}</p>
                </div>

                <p className="text-foreground/90 text-lg max-w-2xl">
                  {bio}
                </p>

                {location && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <MapPin className="w-4 h-4" />
                    <span>{location}</span>
                  </div>
                )}

                {/* Stats */}
                <div className="flex flex-wrap gap-6">
                  <div className="glass rounded-xl px-6 py-3 border border-primary/30 hover:border-primary/50 transition-all">
                    <div className="flex items-center gap-3">
                      <Zap className="w-5 h-5 text-primary" />
                      <div>
                        <div className="text-2xl font-bold text-primary">
                          {resonance}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Resonancia
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="glass rounded-xl px-6 py-3 border border-biometric/30 hover:border-biometric/50 transition-all">
                    <div className="flex items-center gap-3">
                      <Coins className="w-5 h-5 text-biometric" />
                      <div>
                        <div className="text-2xl font-bold text-biometric">
                          {credits}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Créditos
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="glass rounded-xl px-6 py-3 border border-neural/30 hover:border-neural/50 transition-all">
                    <div className="flex items-center gap-3">
                      <Star className="w-5 h-5 text-neural" />
                      <div>
                        <div className="text-2xl font-bold text-neural">
                          {achievements}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Logros
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
