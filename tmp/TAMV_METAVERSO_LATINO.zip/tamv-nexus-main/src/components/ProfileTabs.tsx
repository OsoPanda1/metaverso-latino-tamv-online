import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { 
  ImageIcon, 
  FileText, 
  Video, 
  Radio, 
  Users, 
  Tv, 
  Heart,
  Sparkles 
} from "lucide-react";

const tabs = [
  { value: "gallery", label: "Galería", icon: ImageIcon },
  { value: "posts", label: "Posts", icon: FileText },
  { value: "reels", label: "Reels", icon: Video },
  { value: "streams", label: "Streams", icon: Radio },
  { value: "groups", label: "Grupos", icon: Users },
  { value: "channels", label: "Canales", icon: Tv },
  { value: "wishlist", label: "Wishlist", icon: Heart },
  { value: "nfts", label: "NFTs", icon: Sparkles },
];

export const ProfileTabs = () => {
  return (
    <div className="container mx-auto px-6 py-12">
      <Tabs defaultValue="gallery" className="w-full">
        <TabsList className="glass-strong border border-primary/20 p-2 h-auto flex-wrap justify-start gap-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <TabsTrigger
                key={tab.value}
                value={tab.value}
                className="data-[state=active]:bg-gradient-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-glow-primary rounded-lg px-4 py-2 gap-2"
              >
                <Icon className="w-4 h-4" />
                <span className="hidden sm:inline">{tab.label}</span>
              </TabsTrigger>
            );
          })}
        </TabsList>

        <div className="mt-8">
          {tabs.map((tab) => (
            <TabsContent key={tab.value} value={tab.value} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((item) => (
                  <Card
                    key={item}
                    className="glass border-primary/20 hover:border-primary/50 transition-all cursor-pointer group overflow-hidden"
                  >
                    <div className="aspect-square bg-gradient-holographic relative">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <tab.icon className="w-16 h-16 text-white/30 group-hover:text-white/50 transition-all" />
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="font-semibold text-lg mb-2">
                        {tab.label} #{item}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        Contenido multisensorial activado por resonancia emocional
                      </p>
                      <div className="flex gap-4 mt-4 text-sm text-muted-foreground">
                        <span>❤️ {Math.floor(Math.random() * 1000)}</span>
                        <span>💬 {Math.floor(Math.random() * 100)}</span>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>
          ))}
        </div>
      </Tabs>
    </div>
  );
};
