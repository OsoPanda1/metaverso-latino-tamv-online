import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Sparkles, Trophy, Ticket, Clock, DollarSign, Users, Gift, Zap } from "lucide-react";
import { TAMVToolbar } from "@/components/TAMVToolbar";
import { EcosystemSidebar } from "@/components/EcosystemSidebar";
import { toast } from "sonner";

export default function TAMVLottery() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [myTickets] = useState(15);
  const [totalPool] = useState(20000);
  const [currentParticipants] = useState(12847);
  const [nextDrawDate] = useState(new Date(2025, 1, 5, 20, 0, 0));

  const prizes = [
    { place: "1º", amount: 50000, winners: 1, color: "from-yellow-400 to-yellow-600" },
    { place: "2º", amount: 25000, winners: 2, color: "from-gray-300 to-gray-500" },
    { place: "3º", amount: 10000, winners: 3, color: "from-amber-600 to-amber-800" },
    { place: "4-10º", amount: 5000, winners: 7, color: "from-primary to-primary/70" },
    { place: "11-50º", amount: 1000, winners: 40, color: "from-secondary to-secondary/70" },
    { place: "51-100º", amount: 500, winners: 50, color: "from-accent to-accent/70" },
  ];

  const recentWinners = [
    { name: "María G.", prize: 50000, tickets: 3, date: "Ene 2025" },
    { name: "Carlos R.", prize: 25000, tickets: 7, date: "Ene 2025" },
    { name: "Ana L.", prize: 25000, tickets: 12, date: "Ene 2025" },
    { name: "Diego M.", prize: 10000, tickets: 2, date: "Dic 2024" },
    { name: "Sofia P.", prize: 10000, tickets: 5, date: "Dic 2024" },
  ];

  const handleBuyTicket = (quantity: number) => {
    toast.success(`¡${quantity} ${quantity === 1 ? "boleto adquirido" : "boletos adquiridos"}!`, {
      description: `Total: $${quantity} USD - Buena suerte en el próximo sorteo 🍀`,
    });
  };

  const getTimeRemaining = () => {
    const now = new Date();
    const diff = nextDrawDate.getTime() - now.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    return { days, hours };
  };

  const { days, hours } = getTimeRemaining();
  const poolProgress = (currentParticipants / totalPool) * 100;

  return (
    <div className="min-h-screen bg-background">
      <TAMVToolbar
        likes={15234}
        comments={4567}
        onLike={() => toast.success("Resonancia enviada")}
        onComment={() => toast.info("Comentarios abiertos")}
      />

      <div className="pt-20 pb-6 px-6 container mx-auto max-w-7xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 mx-auto bg-gradient-holographic rounded-2xl flex items-center justify-center pulse-glow mb-4">
            <Trophy className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold text-holographic mb-2">Lotería TAMV™</h1>
          <p className="text-xl text-muted-foreground mb-4">
            20,000 oportunidades mensuales • Solo $1 USD por boleto
          </p>
          <Badge className="text-lg py-2 px-6 bg-gradient-primary border-0 shadow-glow-primary">
            <Gift className="w-5 h-5 mr-2" />
            Premio Acumulado: $150,000 USD
          </Badge>
        </div>

        {/* Countdown and Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="glass-strong border-primary/30 p-6">
            <div className="flex items-center gap-3 mb-4">
              <Clock className="w-8 h-8 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Próximo Sorteo</p>
                <p className="text-2xl font-bold text-holographic">
                  {days}d {hours}h
                </p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              {nextDrawDate.toLocaleDateString("es-MX", {
                day: "numeric",
                month: "long",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
              })}
            </p>
          </Card>

          <Card className="glass-strong border-biometric/30 p-6">
            <div className="flex items-center gap-3 mb-4">
              <Ticket className="w-8 h-8 text-biometric" />
              <div>
                <p className="text-sm text-muted-foreground">Mis Boletos</p>
                <p className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-biometric to-quantum">
                  {myTickets}
                </p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Probabilidad: {((myTickets / totalPool) * 100).toFixed(3)}%
            </p>
          </Card>

          <Card className="glass-strong border-neural/30 p-6">
            <div className="flex items-center gap-3 mb-4">
              <Users className="w-8 h-8 text-neural" />
              <div>
                <p className="text-sm text-muted-foreground">Participantes</p>
                <p className="text-2xl font-bold text-neural">{currentParticipants.toLocaleString()}</p>
              </div>
            </div>
            <Progress value={poolProgress} className="mb-1" />
            <p className="text-xs text-muted-foreground">
              {poolProgress.toFixed(1)}% del pool lleno
            </p>
          </Card>
        </div>

        {/* Buy Tickets */}
        <Card className="glass-strong border-primary/30 p-8 mb-8">
          <h2 className="text-2xl font-bold text-holographic mb-6 flex items-center gap-2">
            <Ticket className="w-6 h-6" />
            Comprar Boletos
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { quantity: 1, bonus: 0, popular: false },
              { quantity: 5, bonus: 1, popular: false },
              { quantity: 10, bonus: 3, popular: true },
              { quantity: 20, bonus: 8, popular: false },
            ].map((option) => (
              <Card
                key={option.quantity}
                className={`glass p-6 text-center cursor-pointer hover:border-primary/50 transition-all ${
                  option.popular ? "border-primary/50 shadow-glow-primary" : "border-primary/20"
                }`}
                onClick={() => handleBuyTicket(option.quantity + option.bonus)}
              >
                {option.popular && (
                  <Badge className="mb-2 bg-gradient-primary border-0">
                    <Sparkles className="w-3 h-3 mr-1" />
                    Popular
                  </Badge>
                )}
                <p className="text-4xl font-bold text-holographic mb-2">{option.quantity}</p>
                {option.bonus > 0 && (
                  <Badge variant="outline" className="mb-2 border-biometric text-biometric">
                    +{option.bonus} BONUS
                  </Badge>
                )}
                <p className="text-sm text-muted-foreground mb-3">boletos</p>
                <Button className="w-full bg-gradient-primary hover:shadow-glow-primary" size="sm">
                  <DollarSign className="w-4 h-4 mr-1" />
                  ${option.quantity}
                </Button>
              </Card>
            ))}
          </div>
        </Card>

        {/* Prize Structure */}
        <Card className="glass-strong border-primary/30 p-8 mb-8">
          <h2 className="text-2xl font-bold text-holographic mb-6 flex items-center gap-2">
            <Trophy className="w-6 h-6" />
            Estructura de Premios
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {prizes.map((prize) => (
              <Card
                key={prize.place}
                className={`glass p-6 bg-gradient-to-br ${prize.color} border-0`}
              >
                <div className="flex items-center justify-between mb-3">
                  <Badge className="bg-black/30 border-0">{prize.place} Lugar</Badge>
                  <Trophy className="w-6 h-6 text-white" />
                </div>
                <p className="text-3xl font-bold text-white mb-2">
                  ${prize.amount.toLocaleString()}
                </p>
                <p className="text-sm text-white/80">
                  {prize.winners} {prize.winners === 1 ? "ganador" : "ganadores"}
                </p>
              </Card>
            ))}
          </div>
        </Card>

        {/* Recent Winners */}
        <Card className="glass-strong border-primary/30 p-8">
          <h2 className="text-2xl font-bold text-holographic mb-6 flex items-center gap-2">
            <Zap className="w-6 h-6" />
            Ganadores Recientes
          </h2>
          <div className="space-y-3">
            {recentWinners.map((winner, index) => (
              <Card
                key={index}
                className="glass border-l-4 border-l-biometric p-4 hover:border-primary/50 transition-all"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-holographic flex items-center justify-center">
                      <Trophy className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="font-bold text-lg">{winner.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {winner.tickets} {winner.tickets === 1 ? "boleto" : "boletos"} • {winner.date}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-biometric">
                      ${winner.prize.toLocaleString()}
                    </p>
                    <Badge variant="outline" className="text-xs">Premio</Badge>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </Card>
      </div>

      <EcosystemSidebar isOpen={sidebarOpen} onToggle={() => setSidebarOpen(!sidebarOpen)} />
    </div>
  );
}
