import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ShoppingCart, Package, Zap, Star, TrendingUp, Filter, Search, Eye } from "lucide-react";
import { TAMVToolbar } from "@/components/TAMVToolbar";
import { EcosystemSidebar } from "@/components/EcosystemSidebar";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

type MarketplaceItem = Tables<"marketplace_items">;

export default function MarketplaceXR() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [items, setItems] = useState<MarketplaceItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [sortBy, setSortBy] = useState("newest");

  useEffect(() => {
    fetchItems();
  }, [categoryFilter, sortBy]);

  const fetchItems = async () => {
    try {
      setLoading(true);
      let query = supabase
        .from("marketplace_items")
        .select("*")
        .eq("sold", false);

      if (categoryFilter !== "all") {
        query = query.eq("asset_type", categoryFilter as any);
      }

      if (sortBy === "price_low") {
        query = query.order("price", { ascending: true });
      } else if (sortBy === "price_high") {
        query = query.order("price", { ascending: false });
      } else {
        query = query.order("created_at", { ascending: false });
      }

      const { data, error } = await query;

      if (error) throw error;
      setItems(data || []);
    } catch (error) {
      console.error("Error fetching items:", error);
      toast.error("Error al cargar items del marketplace");
    } finally {
      setLoading(false);
    }
  };

  const handlePurchase = async (item: MarketplaceItem) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error("Debes iniciar sesión para comprar");
        return;
      }

      // Create purchase record
      const { error: purchaseError } = await supabase
        .from("marketplace_purchases")
        .insert({
          buyer_id: user.id,
          item_id: item.id,
          purchase_price: item.price,
        });

      if (purchaseError) throw purchaseError;

      // Mark item as sold
      const { error: updateError } = await supabase
        .from("marketplace_items")
        .update({ sold: true })
        .eq("id", item.id);

      if (updateError) throw updateError;

      toast.success(`¡Compraste ${item.name}!`, {
        description: `Precio: $${item.price}`,
      });

      fetchItems();
    } catch (error) {
      console.error("Error purchasing item:", error);
      toast.error("Error al realizar la compra");
    }
  };

  const filteredItems = items.filter((item) =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (item.description?.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const getAssetIcon = (type: string) => {
    switch (type) {
      case "avatar":
        return "👤";
      case "space":
        return "🏛️";
      case "object":
        return "🎁";
      case "experience":
        return "✨";
      case "nft":
        return "🖼️";
      default:
        return "📦";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <TAMVToolbar
        likes={15432}
        comments={4821}
        onLike={() => toast.success("Resonancia enviada")}
        onComment={() => toast.info("Comentarios abiertos")}
      />

      <div className="pt-20 pb-6 px-6 container mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-gradient-primary rounded-2xl flex items-center justify-center pulse-glow">
              <ShoppingCart className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-holographic">Marketplace XR</h1>
              <p className="text-muted-foreground text-lg">
                Assets digitales, NFTs y experiencias inmersivas
              </p>
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <Card className="glass-strong border-primary/30 p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Buscar assets..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 glass border-primary/30"
              />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full md:w-48 glass border-primary/30">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Categoría" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                <SelectItem value="avatar">Avatares</SelectItem>
                <SelectItem value="space">Espacios</SelectItem>
                <SelectItem value="object">Objetos</SelectItem>
                <SelectItem value="experience">Experiencias</SelectItem>
                <SelectItem value="nft">NFTs</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-48 glass border-primary/30">
                <TrendingUp className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Ordenar" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Más recientes</SelectItem>
                <SelectItem value="price_low">Menor precio</SelectItem>
                <SelectItem value="price_high">Mayor precio</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </Card>

        {/* Items Grid */}
        <Tabs defaultValue="marketplace" className="w-full">
          <TabsList className="glass-strong border border-primary/20 w-full justify-start mb-6">
            <TabsTrigger value="marketplace" className="gap-2">
              <Package className="w-4 h-4" />
              Marketplace
            </TabsTrigger>
            <TabsTrigger value="auctions" className="gap-2">
              <Zap className="w-4 h-4" />
              Subastas
            </TabsTrigger>
          </TabsList>

          <TabsContent value="marketplace">
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <Card key={i} className="glass-strong border-primary/20 p-6 animate-pulse">
                    <div className="h-48 bg-primary/10 rounded-lg mb-4" />
                    <div className="h-6 bg-primary/10 rounded mb-2" />
                    <div className="h-4 bg-primary/10 rounded w-2/3" />
                  </Card>
                ))}
              </div>
            ) : filteredItems.length === 0 ? (
              <Card className="glass-strong border-primary/30 p-12 text-center">
                <Package className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-xl font-semibold mb-2">No se encontraron items</h3>
                <p className="text-muted-foreground">
                  Intenta ajustar tus filtros de búsqueda
                </p>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredItems.map((item) => (
                  <Card
                    key={item.id}
                    className="glass-strong border-primary/20 hover:border-primary/50 hover:shadow-glow-primary transition-all overflow-hidden group"
                  >
                    {/* Item Image */}
                    <div className="relative h-48 bg-gradient-holographic overflow-hidden">
                      {item.image_url ? (
                        <img
                          src={item.image_url}
                          alt={item.name}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                        />
                      ) : (
                        <div className="flex items-center justify-center h-full text-6xl">
                          {getAssetIcon(item.asset_type)}
                        </div>
                      )}
                      <Badge className="absolute top-4 right-4 bg-gradient-primary border-0">
                        {item.asset_type}
                      </Badge>
                    </div>

                    {/* Item Info */}
                    <div className="p-6 space-y-4">
                      <div>
                        <h3 className="text-xl font-bold text-holographic mb-1">
                          {item.name}
                        </h3>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {item.description}
                        </p>
                      </div>

                      {/* Price */}
                      <div className="flex items-center justify-between pt-4 border-t border-primary/20">
                        <div>
                          <p className="text-xs text-muted-foreground">Precio</p>
                          <p className="text-2xl font-bold text-holographic">
                            ${Number(item.price).toLocaleString()}
                          </p>
                        </div>
                        <Button
                          onClick={() => handlePurchase(item)}
                          className="bg-gradient-primary hover:shadow-glow-primary"
                        >
                          <ShoppingCart className="w-4 h-4 mr-2" />
                          Comprar
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="auctions">
            <Card className="glass-strong border-primary/30 p-12 text-center">
              <Zap className="w-16 h-16 mx-auto mb-4 text-holographic pulse-glow" />
              <h3 className="text-2xl font-bold mb-2">Subastas Próximamente</h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                Participa en subastas en vivo de assets exclusivos y experiencias únicas
              </p>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <EcosystemSidebar
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
      />
    </div>
  );
}
