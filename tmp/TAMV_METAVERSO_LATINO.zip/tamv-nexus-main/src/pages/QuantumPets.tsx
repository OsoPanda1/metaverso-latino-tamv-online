import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sparkles, Zap, Heart, Star, Crown, Gift, Infinity } from "lucide-react";
import { TAMVToolbar } from "@/components/TAMVToolbar";
import { EcosystemSidebar } from "@/components/EcosystemSidebar";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

type QuantumPet = Tables<"quantum_pets">;

const MEMBERSHIP_LEVELS = [
  { name: "Free", color: "#6b7280", powers: 1 },
  { name: "Premium", color: "#3b82f6", powers: 2 },
  { name: "VIP", color: "#06b6d4", powers: 3 },
  { name: "Elite", color: "#8b5cf6", powers: 4 },
  { name: "Celestial", color: "#0ea5e9", powers: 5 },
  { name: "Gold Plus", color: "#fbbf24", powers: 10 },
];

export default function QuantumPets() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [membership] = useState(MEMBERSHIP_LEVELS[2]);
  const [showFusion, setShowFusion] = useState(false);
  const [pets, setPets] = useState<QuantumPet[]>([]);
  const [loading, setLoading] = useState(true);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [newPetName, setNewPetName] = useState("");
  const [newPetType, setNewPetType] = useState("");

  useEffect(() => {
    fetchPets();

    // Subscribe to realtime updates
    const channel = supabase
      .channel("quantum_pets_changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "quantum_pets",
        },
        () => {
          fetchPets();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchPets = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from("quantum_pets")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setPets(data || []);
    } catch (error) {
      console.error("Error fetching pets:", error);
      toast.error("Error al cargar mascotas");
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePet = async () => {
    try {
      if (!newPetName || !newPetType) {
        toast.error("Completa todos los campos");
        return;
      }

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error("Debes iniciar sesión");
        return;
      }

      const { error } = await supabase.from("quantum_pets").insert({
        user_id: user.id,
        name: newPetName,
        pet_type: newPetType,
        level: 1,
        happiness: 75.0,
        energy: 100.0,
        health: 100.0,
        experience: 0,
        quantum_bond: 0.5,
        emotion: "neutral",
        motto: "¡Una nueva aventura comienza!",
        avatar_url: `https://api.dicebear.com/7.x/bottts/svg?seed=${newPetName.toLowerCase()}`,
      });

      if (error) throw error;

      toast.success(`¡${newPetName} se ha unido a tu equipo! 🎉`);
      setCreateDialogOpen(false);
      setNewPetName("");
      setNewPetType("");
      fetchPets();
    } catch (error) {
      console.error("Error creating pet:", error);
      toast.error("Error al crear mascota");
    }
  };

  const handleFeed = async (pet: QuantumPet) => {
    try {
      const newEnergy = Math.min((pet.energy || 0) + 15, 100);
      const { error } = await supabase
        .from("quantum_pets")
        .update({ energy: newEnergy })
        .eq("id", pet.id);

      if (error) throw error;
      toast.success(`${pet.name} ha sido energizada! +15 energía 🔋`);
    } catch (error) {
      console.error("Error feeding pet:", error);
      toast.error("Error al energizar mascota");
    }
  };

  const handleEvolve = async (pet: QuantumPet) => {
    try {
      if ((pet.experience || 0) < 100) {
        toast.info("Necesitas más experiencia para evolucionar");
        return;
      }

      const newLevel = (pet.level || 1) + 1;
      const { error } = await supabase
        .from("quantum_pets")
        .update({ level: newLevel, experience: 0 })
        .eq("id", pet.id);

      if (error) throw error;
      toast.success(`¡${pet.name} evolucionó al nivel ${newLevel}! ✨`);
    } catch (error) {
      console.error("Error evolving pet:", error);
      toast.error("Error al evolucionar mascota");
    }
  };

  const handlePlay = async (pet: QuantumPet) => {
    try {
      const newHappiness = Math.min((pet.happiness || 0) + 10, 100);
      const newExperience = (pet.experience || 0) + 5;
      
      const { error } = await supabase
        .from("quantum_pets")
        .update({ 
          happiness: newHappiness,
          experience: newExperience 
        })
        .eq("id", pet.id);

      if (error) throw error;
      toast.success(`Jugando con ${pet.name}! +10 felicidad +5 XP 💖`);
    } catch (error) {
      console.error("Error playing with pet:", error);
      toast.error("Error al jugar con mascota");
    }
  };

  const getPetEmoji = (type: string) => {
    if (type.toLowerCase().includes("dragón")) return "🐉";
    if (type.toLowerCase().includes("fénix")) return "🔥";
    if (type.toLowerCase().includes("gato")) return "😺";
    if (type.toLowerCase().includes("lobo")) return "🐺";
    if (type.toLowerCase().includes("águila")) return "🦅";
    if (type.toLowerCase().includes("león")) return "🦁";
    if (type.toLowerCase().includes("mariposa")) return "🦋";
    if (type.toLowerCase().includes("oso")) return "🐻";
    if (type.toLowerCase().includes("delfín")) return "🐬";
    if (type.toLowerCase().includes("búho")) return "🦉";
    return "✨";
  };

  return (
    <div className="min-h-screen bg-background">
      <TAMVToolbar
        likes={8765}
        comments={2341}
        onLike={() => toast.success("Resonancia enviada")}
        onComment={() => toast.info("Comentarios abiertos")}
      />

      <div className="pt-20 pb-6 px-6 container mx-auto">
        <div className="text-center mb-8">
          <div className="mb-4">
            <div className="w-20 h-20 mx-auto bg-gradient-holographic rounded-2xl flex items-center justify-center pulse-glow mb-4">
              <Sparkles className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-5xl font-bold text-holographic mb-2">
              Mascotas Cuánticas XR 5D
            </h1>
            <p className="text-xl text-muted-foreground">
              Conexión emocional multisensorial Web 4.0
            </p>
          </div>

          <Badge
            className="text-lg py-2 px-6 mb-4"
            style={{
              background: `linear-gradient(90deg, ${membership.color}, #06b6d4)`,
              boxShadow: `0 0 24px ${membership.color}90`,
            }}
          >
            <Crown className="w-5 h-5 mr-2" />
            Membresía: {membership.name}
          </Badge>

          <Button
            onClick={() => setShowFusion(!showFusion)}
            className={`${
              showFusion
                ? "bg-gradient-to-r from-purple-600 to-cyan-500"
                : "bg-gradient-to-r from-blue-600 to-cyan-400"
            } text-white px-8 py-3 hover:shadow-glow-primary`}
          >
            <Infinity className="w-5 h-5 mr-2" />
            {showFusion ? "Salir de Fusión DAO" : "Entrar a Fusión DAO Global"}
          </Button>
        </div>

        {showFusion && (
          <Card className="glass-strong border-primary/30 p-6 mb-8">
            <h2 className="text-2xl font-bold text-holographic mb-4 flex items-center gap-2">
              <Infinity className="w-6 h-6" />
              Modo Fusión DAO Comunitaria
            </h2>
            <p className="text-muted-foreground mb-4">
              En este modo, la comunidad global vota eventos, entrenamientos y evoluciones
              colectivas, llevando tus mascotas cuánticas a nuevas dimensiones de poder.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {["Entrenamiento Masivo", "Evento de Evolución", "Misión Comunitaria"].map(
                (event) => (
                  <Card
                    key={event}
                    className="glass border-biometric/30 p-4 hover:border-biometric/50 transition-all cursor-pointer"
                  >
                    <h3 className="font-semibold mb-2">{event}</h3>
                    <Progress value={Math.random() * 100} className="mb-2" />
                    <p className="text-xs text-muted-foreground">
                      {Math.floor(Math.random() * 1000)} votos
                    </p>
                  </Card>
                )
              )}
            </div>
          </Card>
        )}

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="glass-strong border-primary/20 p-6 animate-pulse">
                <div className="h-48 bg-primary/10 rounded-lg mb-4" />
                <div className="h-6 bg-primary/10 rounded mb-2" />
                <div className="h-4 bg-primary/10 rounded w-2/3" />
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pets.map((pet) => (
              <Card
                key={pet.id}
                className="glass-strong border-primary/20 hover:border-primary/50 hover:shadow-glow-primary transition-all overflow-hidden"
              >
                {/* Pet Avatar */}
                <div className="relative h-48 bg-gradient-holographic">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-8xl pulse-glow">{getPetEmoji(pet.pet_type)}</div>
                  </div>
                  <Badge className="absolute top-4 right-4 bg-gradient-primary border-0 shadow-glow-primary">
                    <Star className="w-3 h-3 mr-1" />
                    Nivel {pet.level}
                  </Badge>
                </div>

                {/* Pet Info */}
                <div className="p-6 space-y-4">
                  <div className="text-center">
                    <h2 className="text-2xl font-bold text-holographic mb-1">{pet.name}</h2>
                    <p className="text-sm text-muted-foreground">{pet.pet_type}</p>
                    <p className="text-xs italic text-accent mt-2">"{pet.motto}"</p>
                  </div>

                  {/* Stats */}
                  <div className="space-y-2">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>Felicidad</span>
                        <span>{pet.happiness?.toFixed(0)}%</span>
                      </div>
                      <Progress value={pet.happiness || 0} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>Energía</span>
                        <span>{pet.energy?.toFixed(0)}%</span>
                      </div>
                      <Progress value={pet.energy || 0} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>Salud</span>
                        <span>{pet.health?.toFixed(0)}%</span>
                      </div>
                      <Progress value={pet.health || 0} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>XP</span>
                        <span>{pet.experience}</span>
                      </div>
                      <Progress value={(pet.experience || 0) % 100} className="h-2" />
                    </div>
                  </div>

                  {/* Quantum Bond */}
                  <div className="pt-4 border-t border-primary/20">
                    <div className="flex items-center gap-2 mb-2">
                      <Infinity className="w-4 h-4 text-quantum" />
                      <span className="text-sm font-medium">Vínculo Cuántico</span>
                    </div>
                    <Progress value={(pet.quantum_bond || 0) * 100} className="h-3 mb-1" />
                    <p className="text-xs text-center text-muted-foreground">
                      {((pet.quantum_bond || 0) * 100).toFixed(1)}% - {pet.emotion}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 pt-4">
                    <Button
                      size="sm"
                      className="flex-1 bg-gradient-to-r from-cyan-600 to-blue-500 hover:shadow-glow-primary"
                      onClick={() => handleFeed(pet)}
                    >
                      <Zap className="w-4 h-4 mr-1" />
                      Energizar
                    </Button>
                    <Button
                      size="sm"
                      className="flex-1 bg-gradient-to-r from-purple-600 to-cyan-500 hover:shadow-glow-primary"
                      onClick={() => handleEvolve(pet)}
                    >
                      <Sparkles className="w-4 h-4 mr-1" />
                      Evolucionar
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-accent/30"
                      onClick={() => handlePlay(pet)}
                    >
                      <Heart className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Create New Pet */}
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogTrigger asChild>
            <Card className="glass border-primary/30 p-8 mt-8 text-center cursor-pointer hover:border-primary/50 transition-all">
              <Gift className="w-16 h-16 mx-auto mb-4 text-holographic" />
              <h3 className="text-2xl font-bold mb-2">Adoptar Nueva Mascota Cuántica</h3>
              <p className="text-muted-foreground mb-4">
                Crea una conexión emocional única con una nueva compañera digital
              </p>
              <Button className="bg-gradient-primary hover:shadow-glow-primary">
                <Sparkles className="w-4 h-4 mr-2" />
                Crear Mascota
              </Button>
            </Card>
          </DialogTrigger>
          <DialogContent className="glass-strong border-primary/30">
            <DialogHeader>
              <DialogTitle className="text-2xl text-holographic">
                Crear Mascota Cuántica
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div>
                <Label htmlFor="name">Nombre</Label>
                <Input
                  id="name"
                  value={newPetName}
                  onChange={(e) => setNewPetName(e.target.value)}
                  placeholder="Ej: Nebula"
                  className="glass border-primary/30 mt-1"
                />
              </div>
              <div>
                <Label htmlFor="type">Tipo</Label>
                <Input
                  id="type"
                  value={newPetType}
                  onChange={(e) => setNewPetType(e.target.value)}
                  placeholder="Ej: Dragón Cuántico"
                  className="glass border-primary/30 mt-1"
                />
              </div>
              <Button
                onClick={handleCreatePet}
                className="w-full bg-gradient-primary hover:shadow-glow-primary"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Crear Mascota
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <EcosystemSidebar
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
      />
    </div>
  );
}
