import { useState } from "react";
import { TAMVToolbar } from "@/components/TAMVToolbar";
import { ProfileHero } from "@/components/ProfileHero";
import { ProfileTabs } from "@/components/ProfileTabs";
import { EcosystemSidebar } from "@/components/EcosystemSidebar";
import { toast } from "sonner";

const Profile = () => {
  const [isFollowing, setIsFollowing] = useState(false);
  const [likes, setLikes] = useState(1337);
  const [comments] = useState(89);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleFollow = () => {
    setIsFollowing(!isFollowing);
    toast.success(isFollowing ? "Has dejado de seguir" : "Ahora sigues este perfil");
  };

  const handleLike = () => {
    setLikes(likes + 1);
    toast.success("💜 Resonancia emocional registrada");
  };

  const handleComment = () => {
    toast.info("💬 Módulo de comentarios multisensoriales");
  };

  const handleTip = () => {
    toast.info("💸 Sistema de reconocimiento espontáneo");
  };

  const handleDonate = () => {
    toast.info("🎁 Módulo de apoyo institucional");
  };

  const handleMembership = () => {
    toast.info("🛡️ Acceso a capas superiores");
  };

  return (
    <div className="min-h-screen bg-background">
      <TAMVToolbar
        onFollow={handleFollow}
        isFollowing={isFollowing}
        likes={likes}
        comments={comments}
        onLike={handleLike}
        onComment={handleComment}
        onTip={handleTip}
        onDonate={handleDonate}
        onMembership={handleMembership}
      />

      <div className="pt-20">
        <ProfileHero
          name="Edwin Maestre"
          username="edwin.maestre"
          bio="Arquitecto de civilizaciones digitales. Constructor del futuro multisensorial. Pionero TAMV en la revolución tecnológica latinoamericana."
          location="Universo TAMV"
          level={42}
          resonance={9847}
          credits={156789}
          achievements={127}
        />

        <ProfileTabs />
      </div>

      <EcosystemSidebar 
        isOpen={sidebarOpen} 
        onToggle={() => setSidebarOpen(!sidebarOpen)}
      />
    </div>
  );
};

export default Profile;
