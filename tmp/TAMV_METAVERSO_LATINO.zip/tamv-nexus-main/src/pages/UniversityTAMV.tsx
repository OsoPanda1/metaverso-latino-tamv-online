import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { GraduationCap, BookOpen, Video, Award, Users, Clock, Star, Sparkles } from "lucide-react";
import { TAMVToolbar } from "@/components/TAMVToolbar";
import { EcosystemSidebar } from "@/components/EcosystemSidebar";
import { toast } from "sonner";

interface Course {
  id: string;
  title: string;
  category: string;
  duration: string;
  level: string;
  students: number;
  rating: number;
  progress?: number;
  instructor: string;
  certification: boolean;
}

export default function UniversityTAMV() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const courses: Course[] = [
    {
      id: "1",
      title: "Introducción a la IA Consciente",
      category: "IA & Tecnología",
      duration: "8 semanas",
      level: "Principiante",
      students: 5420,
      rating: 4.9,
      progress: 45,
      instructor: "Dr. Isabella Core",
      certification: true,
    },
    {
      id: "2",
      title: "Desarrollo Web3 y Blockchain",
      category: "Blockchain",
      duration: "12 semanas",
      level: "Intermedio",
      students: 3280,
      rating: 4.8,
      instructor: "Eduardo Quantum",
      certification: true,
    },
    {
      id: "3",
      title: "Arte Generativo con IA",
      category: "Arte & Cultura",
      duration: "6 semanas",
      level: "Principiante",
      students: 7650,
      rating: 4.9,
      progress: 78,
      instructor: "Sofía Neural",
      certification: true,
    },
    {
      id: "4",
      title: "Economía Digital Ética",
      category: "Economía",
      duration: "10 semanas",
      level: "Avanzado",
      students: 2180,
      rating: 4.7,
      instructor: "Ricardo Valor",
      certification: true,
    },
    {
      id: "5",
      title: "Content Creation Pro",
      category: "Contenido Digital",
      duration: "4 semanas",
      level: "Intermedio",
      students: 12340,
      rating: 5.0,
      progress: 23,
      instructor: "Ana Creativa",
      certification: true,
    },
    {
      id: "6",
      title: "Seguridad Cuántica",
      category: "Ciberseguridad",
      duration: "16 semanas",
      level: "Avanzado",
      students: 1560,
      rating: 4.9,
      instructor: "Miguel Dekateotl",
      certification: true,
    },
  ];

  const myCourses = courses.filter((c) => c.progress !== undefined);
  const availableCourses = courses.filter((c) => c.progress === undefined);

  const stats = [
    { label: "Cursos Completados", value: 8, icon: Award, color: "primary" },
    { label: "Horas de Estudio", value: 124, icon: Clock, color: "secondary" },
    { label: "Certificaciones", value: 8, icon: GraduationCap, color: "accent" },
    { label: "Rango Global", value: 156, icon: Star, color: "quantum" },
  ];

  const handleEnroll = (courseTitle: string) => {
    toast.success(`¡Inscrito en ${courseTitle}!`, {
      description: "Curso agregado a tu biblioteca. ¡Comienza a aprender!",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <TAMVToolbar
        likes={9876}
        comments={2345}
        onLike={() => toast.success("Resonancia enviada")}
        onComment={() => toast.info("Comentarios abiertos")}
      />

      <div className="pt-20 pb-6 px-6 container mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-gradient-holographic rounded-2xl flex items-center justify-center pulse-glow">
              <GraduationCap className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-holographic">Universidad TAMV™</h1>
              <p className="text-muted-foreground text-lg">
                Educación XR Gratuita • Certificaciones Blockchain
              </p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {stats.map((stat) => (
              <Card key={stat.label} className="glass border-primary/20 p-4">
                <div className="flex items-center gap-2 mb-2">
                  <stat.icon className={`w-4 h-4 text-${stat.color}`} />
                  <span className="text-xs text-muted-foreground">{stat.label}</span>
                </div>
                <p className={`text-2xl font-bold text-${stat.color}`}>{stat.value}</p>
              </Card>
            ))}
          </div>
        </div>

        <Tabs defaultValue="my-courses" className="w-full">
          <TabsList className="glass-strong border border-primary/20 w-full justify-start">
            <TabsTrigger value="my-courses" className="gap-2">
              <BookOpen className="w-4 h-4" />
              Mis Cursos ({myCourses.length})
            </TabsTrigger>
            <TabsTrigger value="available" className="gap-2">
              <Sparkles className="w-4 h-4" />
              Catálogo
            </TabsTrigger>
            <TabsTrigger value="live" className="gap-2">
              <Video className="w-4 h-4" />
              En Vivo
            </TabsTrigger>
          </TabsList>

          <TabsContent value="my-courses" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {myCourses.map((course) => (
                <Card
                  key={course.id}
                  className="glass-strong border-primary/20 hover:border-primary/50 transition-all overflow-hidden group cursor-pointer"
                >
                  <div className="h-48 bg-gradient-holographic relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <BookOpen className="w-16 h-16 text-white/30 group-hover:text-white/50 transition-all" />
                    </div>
                    <Badge className="absolute top-4 left-4 bg-gradient-primary border-0">
                      {course.level}
                    </Badge>
                    {course.certification && (
                      <Badge className="absolute top-4 right-4 bg-gradient-to-r from-biometric to-quantum border-0">
                        <Award className="w-3 h-3 mr-1" />
                        Certificación
                      </Badge>
                    )}
                  </div>
                  <div className="p-6 space-y-4">
                    <div>
                      <Badge variant="outline" className="mb-2 text-xs">
                        {course.category}
                      </Badge>
                      <h3 className="text-xl font-bold mb-2">{course.title}</h3>
                      <p className="text-sm text-muted-foreground">Por {course.instructor}</p>
                    </div>

                    {course.progress !== undefined && (
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span>Progreso</span>
                          <span className="font-medium">{course.progress}%</span>
                        </div>
                        <Progress value={course.progress} className="h-2" />
                      </div>
                    )}

                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {course.duration}
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        {course.students.toLocaleString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-current text-accent" />
                        {course.rating}
                      </div>
                    </div>

                    <Button className="w-full bg-gradient-primary hover:shadow-glow-primary">
                      Continuar Curso
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="available" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {availableCourses.map((course) => (
                <Card
                  key={course.id}
                  className="glass-strong border-primary/20 hover:border-primary/50 transition-all overflow-hidden group cursor-pointer"
                >
                  <div className="h-48 bg-gradient-holographic relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <BookOpen className="w-16 h-16 text-white/30 group-hover:text-white/50 transition-all" />
                    </div>
                    <Badge className="absolute top-4 left-4 bg-gradient-primary border-0">
                      {course.level}
                    </Badge>
                    {course.certification && (
                      <Badge className="absolute top-4 right-4 bg-gradient-to-r from-biometric to-quantum border-0">
                        <Award className="w-3 h-3 mr-1" />
                        Certificación
                      </Badge>
                    )}
                    <Badge className="absolute bottom-4 left-4 bg-black/50 backdrop-blur border-0">
                      🎓 GRATIS
                    </Badge>
                  </div>
                  <div className="p-6 space-y-4">
                    <div>
                      <Badge variant="outline" className="mb-2 text-xs">
                        {course.category}
                      </Badge>
                      <h3 className="text-xl font-bold mb-2">{course.title}</h3>
                      <p className="text-sm text-muted-foreground">Por {course.instructor}</p>
                    </div>

                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {course.duration}
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        {course.students.toLocaleString()}
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-current text-accent" />
                        {course.rating}
                      </div>
                    </div>

                    <Button
                      onClick={() => handleEnroll(course.title)}
                      className="w-full bg-gradient-to-r from-secondary to-accent hover:shadow-glow-primary"
                    >
                      Inscribirse Gratis
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="live" className="mt-6">
            <Card className="glass-strong border-primary/30 p-12 text-center">
              <div className="w-20 h-20 mx-auto bg-gradient-to-r from-destructive to-pink-500 rounded-full flex items-center justify-center mb-6 pulse-glow">
                <Video className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-holographic mb-4">Clases en Vivo Próximamente</h3>
              <p className="text-muted-foreground text-lg mb-6 max-w-2xl mx-auto">
                Estamos preparando una experiencia de aprendizaje en tiempo real con transmisiones XR multisensoriales.
                Únete a la comunidad para recibir notificaciones.
              </p>
              <Button className="bg-gradient-to-r from-destructive to-pink-500 hover:shadow-glow-primary">
                <Users className="w-5 h-5 mr-2" />
                Unirme a la Lista de Espera
              </Button>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <EcosystemSidebar isOpen={sidebarOpen} onToggle={() => setSidebarOpen(!sidebarOpen)} />
    </div>
  );
}
