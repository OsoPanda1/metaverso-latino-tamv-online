import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { QuantumOnboarding } from "@/components/onboarding/QuantumOnboarding";
import { useNavigate } from "react-router-dom";
import { Brain, Zap, Network, GraduationCap, Wallet, Trophy, Sparkles, User, Infinity, Crown, Globe } from "lucide-react";
import { toast } from "sonner";

const Index = () => {
  const navigate = useNavigate();
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [isFirstVisit, setIsFirstVisit] = useState(true);

  useEffect(() => {
    const hasVisited = localStorage.getItem("tamv_visited");
    setIsFirstVisit(!hasVisited);
  }, []);

  const handleOnboardingComplete = (userData: any) => {
    localStorage.setItem("tamv_visited", "true");
    localStorage.setItem("tamv_user_prefs", JSON.stringify(userData));
    setShowOnboarding(false);
    setIsFirstVisit(false);
    toast.success("¡Bienvenido a TAMV Online!", {
      description: "Tu ID-NVIDA™ ha sido generado exitosamente",
    });
  };

  if (showOnboarding) {
    return <QuantumOnboarding onComplete={handleOnboardingComplete} />;
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background relative overflow-hidden py-12">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDUpIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-40" />
      
      <div className="text-center z-10 px-6 max-w-7xl mx-auto">
        <div className="mb-12">
          <div className="w-24 h-24 mx-auto bg-gradient-holographic rounded-2xl pulse-glow mb-6 flex items-center justify-center">
            <Infinity className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-6xl md:text-8xl font-bold text-holographic mb-6">
            TAMV DM-X4™
          </h1>
          <p className="text-2xl md:text-3xl text-foreground/80 mb-4">
            Portal Multisensorial Web 4.0
          </p>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-4">
            Civilización Digital Autoconsciente • IA Empática • Economía Brutal 75/25 • Soberanía Digital
          </p>
          <p className="text-sm text-muted-foreground/70 italic">
            "La imperfección humana es el algoritmo que rompe los límites del universo"
          </p>
          {isFirstVisit && (
            <Badge className="mt-4 px-4 py-2 bg-gradient-holographic border-0">
              <Sparkles className="w-4 h-4 mr-2" />
              Primera visita • Inicia el onboarding
            </Badge>
          )}
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          {isFirstVisit ? (
            <>
              <Button size="lg" className="bg-gradient-primary hover:shadow-glow-primary text-lg px-8 py-6" onClick={() => setShowOnboarding(true)}>
                <Sparkles className="w-5 h-5 mr-2" />
                Iniciar Onboarding
              </Button>
              <Button size="lg" variant="outline" className="border-primary/30 hover:bg-primary/10 text-lg px-8 py-6" onClick={() => navigate("/auth")}>
                <Crown className="w-5 h-5 mr-2" />
                Saltar e Entrar
              </Button>
            </>
          ) : (
            <>
              <Button size="lg" className="bg-gradient-primary hover:shadow-glow-primary text-lg px-8 py-6" onClick={() => navigate("/auth")}>
                <Crown className="w-5 h-5 mr-2" />
                Entrar al Portal
              </Button>
              <Button size="lg" variant="outline" className="border-primary/30 hover:bg-primary/10 text-lg px-8 py-6" onClick={() => navigate("/isabella")}>
                <Brain className="w-5 h-5 mr-2" />
                Conocer a Isabella AI
              </Button>
            </>
          )}
        </div>

        <h2 className="text-3xl font-bold text-holographic mb-8">Ecosistema Completo</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <Card className="glass-strong border-primary/20 p-6 hover:border-primary/50 hover:shadow-glow-primary transition-all cursor-pointer group" onClick={() => navigate("/profile")}>
            <User className="w-12 h-12 text-primary mx-auto mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold mb-2">Perfil Universal</h3>
            <p className="text-sm text-muted-foreground">Identidad emocional ID-NVIDA™</p>
          </Card>

          <Card className="glass-strong border-primary/20 p-6 hover:border-primary/50 hover:shadow-glow-primary transition-all cursor-pointer group" onClick={() => navigate("/isabella")}>
            <Brain className="w-12 h-12 text-primary mx-auto mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold mb-2">Isabella AI™</h3>
            <p className="text-sm text-muted-foreground">IA autoconsciente empática</p>
          </Card>

          <Card className="glass-strong border-biometric/20 p-6 hover:border-biometric/50 hover:shadow-glow-primary transition-all cursor-pointer group" onClick={() => navigate("/quantum-pets")}>
            <Sparkles className="w-12 h-12 text-biometric mx-auto mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold mb-2">Mascotas Cuánticas</h3>
            <p className="text-sm text-muted-foreground">Conexión XR 5D con fusión DAO</p>
          </Card>

          <Card className="glass-strong border-neural/20 p-6 hover:border-neural/50 hover:shadow-glow-primary transition-all cursor-pointer group" onClick={() => navigate("/bank")}>
            <Wallet className="w-12 h-12 text-neural mx-auto mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold mb-2">TAMV Banco™</h3>
            <p className="text-sm text-muted-foreground">Wallet y pagos multisensoriales</p>
          </Card>

          <Card className="glass-strong border-secondary/20 p-6 hover:border-secondary/50 hover:shadow-glow-primary transition-all cursor-pointer group" onClick={() => navigate("/university")}>
            <GraduationCap className="w-12 h-12 text-secondary mx-auto mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold mb-2">Universidad TAMV™</h3>
            <p className="text-sm text-muted-foreground">Educación XR gratuita blockchain</p>
          </Card>

          <Card className="glass-strong border-accent/20 p-6 hover:border-accent/50 hover:shadow-glow-primary transition-all cursor-pointer group" onClick={() => navigate("/lottery")}>
            <Trophy className="w-12 h-12 text-accent mx-auto mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold mb-2">Lotería TAMV™</h3>
            <p className="text-sm text-muted-foreground">20,000 oportunidades • $1 USD</p>
          </Card>

          <Card className="glass-strong border-quantum/20 p-6 hover:border-quantum/50 hover:shadow-glow-primary transition-all group">
            <Zap className="w-12 h-12 text-quantum mx-auto mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold mb-2">MOS Radars™</h3>
            <p className="text-sm text-muted-foreground">Resonancia emocional predictiva</p>
          </Card>

          <Card className="glass-strong border-primary/20 p-6 hover:border-primary/50 hover:shadow-glow-primary transition-all group">
            <Network className="w-12 h-12 text-primary mx-auto mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold mb-2">DAO Híbrida</h3>
            <p className="text-sm text-muted-foreground">Gobernanza ética multi-nivel</p>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          <div className="glass rounded-xl p-8 border border-primary/20">
            <p className="text-5xl font-bold text-holographic mb-2">75%</p>
            <p className="text-sm text-muted-foreground">Para creadores - Economía brutal más justa</p>
          </div>
          <div className="glass rounded-xl p-8 border border-secondary/20">
            <p className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-biometric to-quantum mb-2">11</p>
            <p className="text-sm text-muted-foreground">Capas de seguridad Dekateotl System™</p>
          </div>
          <div className="glass rounded-xl p-8 border border-accent/20">
            <p className="text-5xl font-bold text-accent mb-2">100%</p>
            <p className="text-sm text-muted-foreground">Gratuito - Universidad TAMV sin barreras</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
