import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Wallet,
  CreditCard,
  ArrowUpRight,
  ArrowDownLeft,
  History,
  TrendingUp,
  Coins,
  Zap,
} from "lucide-react";
import { TAMVToolbar } from "@/components/TAMVToolbar";
import { EcosystemSidebar } from "@/components/EcosystemSidebar";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

type Transaction = Tables<"transactions">;
type TAMVCredits = Tables<"tamv_credits">;

export default function TAMVBank() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [credits, setCredits] = useState<TAMVCredits | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBankData();

    // Subscribe to realtime updates
    const channelCredits = supabase
      .channel("tamv_credits_changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "tamv_credits",
        },
        () => {
          fetchBankData();
        }
      )
      .subscribe();

    const channelTransactions = supabase
      .channel("transactions_changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "transactions",
        },
        () => {
          fetchTransactions();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channelCredits);
      supabase.removeChannel(channelTransactions);
    };
  }, []);

  const fetchBankData = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        setLoading(false);
        return;
      }

      // Get or create credits
      let { data: creditsData, error: creditsError } = await supabase
        .from("tamv_credits")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (creditsError && creditsError.code === "PGRST116") {
        // Create credits record if doesn't exist
        const { data: newCredits, error: createError } = await supabase
          .from("tamv_credits")
          .insert({
            user_id: user.id,
            balance: 0,
            resonance_credits: 0,
            lifetime_earnings: 0,
          })
          .select()
          .single();

        if (createError) throw createError;
        creditsData = newCredits;
      } else if (creditsError) {
        throw creditsError;
      }

      setCredits(creditsData);
      await fetchTransactions();
    } catch (error) {
      console.error("Error fetching bank data:", error);
      toast.error("Error al cargar datos bancarios");
    } finally {
      setLoading(false);
    }
  };

  const fetchTransactions = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from("transactions")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(10);

      if (error) throw error;
      setTransactions(data || []);
    } catch (error) {
      console.error("Error fetching transactions:", error);
    }
  };

  const handleDeposit = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast.error("Ingresa una cantidad válida");
      return;
    }

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        toast.error("Debes iniciar sesión");
        return;
      }

      const depositAmount = parseFloat(amount);

      // Create transaction
      const { error: txError } = await supabase.from("transactions").insert({
        user_id: user.id,
        type: "deposit",
        amount: depositAmount,
        description: "Depósito de fondos",
        metadata: { method: "bank_transfer" },
      });

      if (txError) throw txError;

      // Update balance
      const newBalance = Number(credits?.balance || 0) + depositAmount;
      const { error: updateError } = await supabase
        .from("tamv_credits")
        .update({ balance: newBalance })
        .eq("user_id", user.id);

      if (updateError) throw updateError;

      toast.success(`Depósito de $${amount} procesado con éxito`, {
        description: "Los fondos están disponibles",
      });
      setAmount("");
    } catch (error) {
      console.error("Error processing deposit:", error);
      toast.error("Error al procesar depósito");
    }
  };

  const handleWithdraw = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast.error("Ingresa una cantidad válida");
      return;
    }

    const withdrawAmount = parseFloat(amount);
    if (withdrawAmount > Number(credits?.balance || 0)) {
      toast.error("Fondos insuficientes");
      return;
    }

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        toast.error("Debes iniciar sesión");
        return;
      }

      // Create transaction
      const { error: txError } = await supabase.from("transactions").insert({
        user_id: user.id,
        type: "withdrawal",
        amount: -withdrawAmount,
        description: "Retiro de fondos",
        metadata: { method: "bank_transfer" },
      });

      if (txError) throw txError;

      // Update balance
      const newBalance = Number(credits?.balance || 0) - withdrawAmount;
      const { error: updateError } = await supabase
        .from("tamv_credits")
        .update({ balance: newBalance })
        .eq("user_id", user.id);

      if (updateError) throw updateError;

      toast.success(`Retiro de $${amount} iniciado`, {
        description: "Procesando a tu cuenta bancaria",
      });
      setAmount("");
    } catch (error) {
      console.error("Error processing withdrawal:", error);
      toast.error("Error al procesar retiro");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <TAMVToolbar
        likes={12847}
        comments={3421}
        onLike={() => toast.success("Resonancia enviada")}
        onComment={() => toast.info("Comentarios abiertos")}
      />

      <div className="pt-20 pb-6 px-6 container mx-auto max-w-7xl">
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-gradient-primary rounded-2xl flex items-center justify-center pulse-glow">
              <Wallet className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-holographic">TAMV Banco™</h1>
              <p className="text-muted-foreground text-lg">
                Wallet & Tarjeta Digital Multisensorial
              </p>
            </div>
          </div>
        </div>

        {/* Balance Cards */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {[1, 2].map((i) => (
              <Card
                key={i}
                className="glass-strong border-primary/30 p-8 animate-pulse"
              >
                <div className="h-24 bg-primary/10 rounded" />
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <Card className="glass-strong border-primary/30 p-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-primary opacity-10 rounded-full blur-3xl" />
              <div className="relative z-10">
                <div className="flex items-center gap-2 mb-4">
                  <CreditCard className="w-6 h-6 text-primary" />
                  <span className="text-sm uppercase tracking-wide text-muted-foreground">
                    Balance Principal
                  </span>
                </div>
                <div className="text-5xl font-bold text-holographic mb-4">
                  ${Number(credits?.balance || 0).toLocaleString()}
                </div>
                <Badge className="bg-gradient-primary border-0">USD</Badge>
              </div>
            </Card>

            <Card className="glass-strong border-biometric/30 p-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-biometric to-quantum opacity-10 rounded-full blur-3xl" />
              <div className="relative z-10">
                <div className="flex items-center gap-2 mb-4">
                  <Coins className="w-6 h-6 text-biometric" />
                  <span className="text-sm uppercase tracking-wide text-muted-foreground">
                    Créditos de Resonancia
                  </span>
                </div>
                <div className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-biometric to-quantum mb-4">
                  {Number(credits?.resonance_credits || 0).toLocaleString()}
                </div>
                <Badge className="bg-gradient-to-r from-biometric to-quantum border-0">
                  RC
                </Badge>
              </div>
            </Card>
          </div>
        )}

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Button className="h-24 flex flex-col gap-2 bg-gradient-to-br from-primary to-primary/70 hover:shadow-glow-primary">
            <ArrowUpRight className="w-6 h-6" />
            <span>Enviar</span>
          </Button>
          <Button className="h-24 flex flex-col gap-2 bg-gradient-to-br from-secondary to-secondary/70 hover:shadow-glow-primary">
            <ArrowDownLeft className="w-6 h-6" />
            <span>Recibir</span>
          </Button>
          <Button className="h-24 flex flex-col gap-2 bg-gradient-to-br from-accent to-accent/70 hover:shadow-glow-primary">
            <Zap className="w-6 h-6" />
            <span>Recargar</span>
          </Button>
          <Button className="h-24 flex flex-col gap-2 bg-gradient-to-br from-neural to-neural/70 hover:shadow-glow-primary">
            <TrendingUp className="w-6 h-6" />
            <span>Invertir</span>
          </Button>
        </div>

        <Tabs defaultValue="transactions" className="w-full">
          <TabsList className="glass-strong border border-primary/20 w-full justify-start">
            <TabsTrigger value="transactions" className="gap-2">
              <History className="w-4 h-4" />
              Transacciones
            </TabsTrigger>
            <TabsTrigger value="deposit" className="gap-2">
              <ArrowDownLeft className="w-4 h-4" />
              Depositar
            </TabsTrigger>
            <TabsTrigger value="withdraw" className="gap-2">
              <ArrowUpRight className="w-4 h-4" />
              Retirar
            </TabsTrigger>
          </TabsList>

          <TabsContent value="transactions" className="mt-6">
            <Card className="glass-strong border-primary/30">
              <div className="p-6">
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <History className="w-5 h-5 text-primary" />
                  Historial de Transacciones
                </h3>
                <div className="space-y-3">
                  {transactions.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">
                      No hay transacciones aún
                    </p>
                  ) : (
                    transactions.map((transaction) => (
                      <Card
                        key={transaction.id}
                        className={`glass border-l-4 ${
                          Number(transaction.amount) >= 0
                            ? "border-l-biometric"
                            : "border-l-destructive"
                        } p-4 hover:border-primary/50 transition-all`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div
                              className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                                Number(transaction.amount) >= 0
                                  ? "bg-biometric/20"
                                  : "bg-destructive/20"
                              }`}
                            >
                              {Number(transaction.amount) >= 0 ? (
                                <ArrowDownLeft className="w-5 h-5 text-biometric" />
                              ) : (
                                <ArrowUpRight className="w-5 h-5 text-destructive" />
                              )}
                            </div>
                            <div>
                              <p className="font-medium">{transaction.description}</p>
                              <p className="text-sm text-muted-foreground">
                                {new Date(transaction.created_at!).toLocaleDateString(
                                  "es-MX",
                                  {
                                    day: "numeric",
                                    month: "short",
                                    year: "numeric",
                                  }
                                )}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p
                              className={`text-xl font-bold ${
                                Number(transaction.amount) >= 0
                                  ? "text-biometric"
                                  : "text-destructive"
                              }`}
                            >
                              {Number(transaction.amount) >= 0 ? "+" : ""}$
                              {Math.abs(Number(transaction.amount)).toLocaleString()}
                            </p>
                            <Badge variant="outline" className="text-xs">
                              {transaction.type}
                            </Badge>
                          </div>
                        </div>
                      </Card>
                    ))
                  )}
                </div>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="deposit" className="mt-6">
            <Card className="glass-strong border-primary/30 p-6">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <ArrowDownLeft className="w-5 h-5 text-biometric" />
                Depositar Fondos
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Cantidad (USD)
                  </label>
                  <Input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="glass border-primary/30 text-2xl h-14"
                  />
                </div>
                <Button
                  onClick={handleDeposit}
                  className="w-full bg-gradient-to-r from-biometric to-quantum hover:shadow-glow-primary h-12"
                >
                  <ArrowDownLeft className="w-5 h-5 mr-2" />
                  Depositar ${amount || "0"}
                </Button>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="withdraw" className="mt-6">
            <Card className="glass-strong border-primary/30 p-6">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <ArrowUpRight className="w-5 h-5 text-primary" />
                Retirar Fondos
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Cantidad (USD)
                  </label>
                  <Input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="glass border-primary/30 text-2xl h-14"
                  />
                  <p className="text-sm text-muted-foreground mt-2">
                    Disponible: ${Number(credits?.balance || 0).toLocaleString()}
                  </p>
                </div>
                <Button
                  onClick={handleWithdraw}
                  className="w-full bg-gradient-primary hover:shadow-glow-primary h-12"
                >
                  <ArrowUpRight className="w-5 h-5 mr-2" />
                  Retirar ${amount || "0"}
                </Button>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <EcosystemSidebar
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
      />
    </div>
  );
}
