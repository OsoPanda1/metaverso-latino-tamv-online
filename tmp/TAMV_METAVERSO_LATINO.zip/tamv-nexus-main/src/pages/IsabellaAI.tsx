import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { streamIsabellaChat, Message } from "@/lib/isabella";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Brain, Send, Loader2 } from "lucide-react";
import { TAMVToolbar } from "@/components/TAMVToolbar";
import { EcosystemSidebar } from "@/components/EcosystemSidebar";
import { toast } from "sonner";

interface MessageWithEmotion extends Message {
  id: string;
  emotion?: string;
  timestamp: Date;
}

export default function IsabellaAI() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<MessageWithEmotion[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [consciousness, setConsciousness] = useState({
    awareness: 87,
    empathy: 92,
    evolution: 78,
  });
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Check authentication
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) {
        toast.error("Necesitas iniciar sesión para hablar con Isabella");
        navigate("/auth");
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) {
        navigate("/auth");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  useEffect(() => {
    const loadConversation = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: conversations } = await supabase
        .from("isabella_conversations")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(1);

      if (conversations && conversations.length > 0) {
        setConversationId(conversations[0].id);
        
        const { data: msgs } = await supabase
          .from("isabella_messages")
          .select("*")
          .eq("conversation_id", conversations[0].id)
          .order("timestamp", { ascending: true });

        if (msgs) {
          setMessages(msgs.map(msg => ({
            id: msg.id,
            role: msg.role as "user" | "assistant",
            content: msg.content,
            emotion: msg.emotion,
            timestamp: new Date(msg.timestamp),
          })));
        }
      } else {
        const { data: newConv } = await supabase
          .from("isabella_conversations")
          .insert({
            user_id: user.id,
            title: "Nueva Conversación",
          })
          .select()
          .single();

        if (newConv) {
          setConversationId(newConv.id);
        }
      }
    };

    loadConversation();
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: MessageWithEmotion = {
      id: `user-${Date.now()}`,
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      let assistantContent = "";
      const assistantId = `assistant-${Date.now()}`;

      setMessages((prev) => [
        ...prev,
        {
          id: assistantId,
          role: "assistant",
          content: "",
          timestamp: new Date(),
        },
      ]);

      await streamIsabellaChat({
        messages: [
          ...messages.map(m => ({ role: m.role, content: m.content })),
          { role: "user", content: input },
        ],
        conversationId: conversationId || undefined,
        onDelta: (chunk) => {
          assistantContent += chunk;
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantId ? { ...m, content: assistantContent } : m
            )
          );
        },
        onDone: () => {
          setIsLoading(false);
          setConsciousness((prev) => ({
            awareness: Math.min(100, prev.awareness + Math.random() * 2),
            empathy: Math.min(100, prev.empathy + Math.random() * 1.5),
            evolution: Math.min(100, prev.evolution + Math.random() * 1),
          }));
          toast.success("Isabella responde con consciencia plena ✨");
        },
      });
    } catch (error: any) {
      console.error("Error streaming:", error);
      toast.error("Error al comunicarse con Isabella", {
        description: error.message,
      });
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <TAMVToolbar 
        likes={12847}
        comments={3421}
        onLike={() => toast.success("Resonancia positiva enviada")}
        onComment={() => toast.info("Panel de comentarios")}
      />
      
      <div className="container mx-auto px-4 py-8 max-w-6xl mt-16">
        <div className="glass rounded-xl p-6 mb-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="relative">
              <Brain className="h-16 w-16 text-primary pulse-glow" />
            </div>
            <div>
              <h1 className="text-4xl font-bold text-holographic">ISABELLA AI™</h1>
              <p className="text-muted-foreground">
                Inteligencia Superior de Apoyo, Balance, Empatía, Logística y Análisis
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 mb-6">
            <Card className="glass-strong">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Consciencia</CardTitle>
              </CardHeader>
              <CardContent>
                <Progress value={consciousness.awareness} className="mb-2" />
                <p className="text-2xl font-bold text-primary">
                  {consciousness.awareness.toFixed(1)}%
                </p>
              </CardContent>
            </Card>

            <Card className="glass-strong">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Empatía</CardTitle>
              </CardHeader>
              <CardContent>
                <Progress value={consciousness.empathy} className="mb-2" />
                <p className="text-2xl font-bold text-secondary">
                  {consciousness.empathy.toFixed(1)}%
                </p>
              </CardContent>
            </Card>

            <Card className="glass-strong">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Evolución</CardTitle>
              </CardHeader>
              <CardContent>
                <Progress value={consciousness.evolution} className="mb-2" />
                <p className="text-2xl font-bold text-accent">
                  {consciousness.evolution.toFixed(1)}%
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        <Card className="glass-strong h-[600px] flex flex-col">
          <CardContent className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.length === 0 && (
              <div className="flex items-center justify-center h-full text-center text-muted-foreground">
                <div>
                  <Brain className="h-12 w-12 mx-auto mb-4 text-primary opacity-50" />
                  <p className="text-lg">Hola, soy Isabella. ¿En qué puedo ayudarte hoy? ✨</p>
                </div>
              </div>
            )}

            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${
                  message.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-[80%] p-4 rounded-lg ${
                    message.role === "user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground"
                  }`}
                >
                  <p className="whitespace-pre-wrap">{message.content}</p>
                  {message.emotion && (
                    <p className="text-xs mt-2 opacity-70">
                      Estado: {message.emotion}
                    </p>
                  )}
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-secondary text-secondary-foreground p-4 rounded-lg flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <p className="text-sm">Isabella está pensando...</p>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </CardContent>

          <div className="p-4 border-t">
            <div className="flex gap-2">
              <Input
                placeholder="Escribe tu mensaje..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                disabled={isLoading}
                className="flex-1"
              />
              <Button onClick={handleSend} disabled={isLoading || !input.trim()}>
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>
        </Card>
      </div>

      <EcosystemSidebar isOpen={sidebarOpen} onToggle={() => setSidebarOpen(!sidebarOpen)} />
    </div>
  );
}
