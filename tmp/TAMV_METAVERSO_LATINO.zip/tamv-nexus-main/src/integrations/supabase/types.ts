export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: string
          compliance_status:
            | Database["public"]["Enums"]["compliance_level"]
            | null
          created_at: string | null
          details: Json | null
          entity_id: string | null
          entity_type: string | null
          id: string
          user_id: string | null
        }
        Insert: {
          action: string
          compliance_status?:
            | Database["public"]["Enums"]["compliance_level"]
            | null
          created_at?: string | null
          details?: Json | null
          entity_id?: string | null
          entity_type?: string | null
          id?: string
          user_id?: string | null
        }
        Update: {
          action?: string
          compliance_status?:
            | Database["public"]["Enums"]["compliance_level"]
            | null
          created_at?: string | null
          details?: Json | null
          entity_id?: string | null
          entity_type?: string | null
          id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      course_enrollments: {
        Row: {
          completed: boolean | null
          completed_at: string | null
          course_id: string
          enrolled_at: string | null
          id: string
          progress: number | null
          user_id: string
        }
        Insert: {
          completed?: boolean | null
          completed_at?: string | null
          course_id: string
          enrolled_at?: string | null
          id?: string
          progress?: number | null
          user_id: string
        }
        Update: {
          completed?: boolean | null
          completed_at?: string | null
          course_id?: string
          enrolled_at?: string | null
          id?: string
          progress?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "course_enrollments_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "university_courses"
            referencedColumns: ["id"]
          },
        ]
      }
      digital_twins: {
        Row: {
          consent_status: boolean | null
          created_at: string | null
          evolution_history: Json | null
          id: string
          name: string
          simulation_data: Json | null
          twin_type: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          consent_status?: boolean | null
          created_at?: string | null
          evolution_history?: Json | null
          id?: string
          name: string
          simulation_data?: Json | null
          twin_type?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          consent_status?: boolean | null
          created_at?: string | null
          evolution_history?: Json | null
          id?: string
          name?: string
          simulation_data?: Json | null
          twin_type?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      dreamspaces: {
        Row: {
          assets: Json | null
          created_at: string | null
          description: string | null
          id: string
          is_public: boolean | null
          name: string
          rating: number | null
          space_type: string | null
          updated_at: string | null
          user_id: string
          visitors: number | null
          xr_config: Json | null
        }
        Insert: {
          assets?: Json | null
          created_at?: string | null
          description?: string | null
          id?: string
          is_public?: boolean | null
          name: string
          rating?: number | null
          space_type?: string | null
          updated_at?: string | null
          user_id: string
          visitors?: number | null
          xr_config?: Json | null
        }
        Update: {
          assets?: Json | null
          created_at?: string | null
          description?: string | null
          id?: string
          is_public?: boolean | null
          name?: string
          rating?: number | null
          space_type?: string | null
          updated_at?: string | null
          user_id?: string
          visitors?: number | null
          xr_config?: Json | null
        }
        Relationships: []
      }
      isabella_conversations: {
        Row: {
          consciousness_level: number | null
          created_at: string | null
          emotion_analysis: Json | null
          empathy_score: number | null
          id: string
          title: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          consciousness_level?: number | null
          created_at?: string | null
          emotion_analysis?: Json | null
          empathy_score?: number | null
          id?: string
          title?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          consciousness_level?: number | null
          created_at?: string | null
          emotion_analysis?: Json | null
          empathy_score?: number | null
          id?: string
          title?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      isabella_messages: {
        Row: {
          content: string
          conversation_id: string
          emotion: Database["public"]["Enums"]["emotion_type"] | null
          id: string
          role: string
          timestamp: string | null
        }
        Insert: {
          content: string
          conversation_id: string
          emotion?: Database["public"]["Enums"]["emotion_type"] | null
          id?: string
          role: string
          timestamp?: string | null
        }
        Update: {
          content?: string
          conversation_id?: string
          emotion?: Database["public"]["Enums"]["emotion_type"] | null
          id?: string
          role?: string
          timestamp?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "isabella_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "isabella_conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      lottery_tickets: {
        Row: {
          created_at: string | null
          draw_id: string | null
          id: string
          is_winner: boolean | null
          prize_amount: number | null
          ticket_number: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          draw_id?: string | null
          id?: string
          is_winner?: boolean | null
          prize_amount?: number | null
          ticket_number: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          draw_id?: string | null
          id?: string
          is_winner?: boolean | null
          prize_amount?: number | null
          ticket_number?: string
          user_id?: string
        }
        Relationships: []
      }
      marketplace_items: {
        Row: {
          asset_type: Database["public"]["Enums"]["asset_type"]
          auction_ends_at: string | null
          created_at: string | null
          current_bid: number | null
          description: string | null
          id: string
          image_url: string | null
          is_auction: boolean | null
          metadata: Json | null
          name: string
          price: number
          seller_id: string
          sold: boolean | null
        }
        Insert: {
          asset_type: Database["public"]["Enums"]["asset_type"]
          auction_ends_at?: string | null
          created_at?: string | null
          current_bid?: number | null
          description?: string | null
          id?: string
          image_url?: string | null
          is_auction?: boolean | null
          metadata?: Json | null
          name: string
          price: number
          seller_id: string
          sold?: boolean | null
        }
        Update: {
          asset_type?: Database["public"]["Enums"]["asset_type"]
          auction_ends_at?: string | null
          created_at?: string | null
          current_bid?: number | null
          description?: string | null
          id?: string
          image_url?: string | null
          is_auction?: boolean | null
          metadata?: Json | null
          name?: string
          price?: number
          seller_id?: string
          sold?: boolean | null
        }
        Relationships: []
      }
      marketplace_purchases: {
        Row: {
          buyer_id: string
          id: string
          item_id: string
          purchase_price: number
          purchased_at: string
          status: string
        }
        Insert: {
          buyer_id: string
          id?: string
          item_id: string
          purchase_price: number
          purchased_at?: string
          status?: string
        }
        Update: {
          buyer_id?: string
          id?: string
          item_id?: string
          purchase_price?: number
          purchased_at?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "marketplace_purchases_item_id_fkey"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "marketplace_items"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          audio_enabled: boolean | null
          avatar_url: string | null
          bio: string | null
          created_at: string | null
          display_name: string | null
          emotion_intensity: number | null
          emotion_state: Database["public"]["Enums"]["emotion_type"] | null
          haptic_enabled: boolean | null
          id: string
          id_nvida: string | null
          institutional_weight: number | null
          onboarding_completed: boolean | null
          preferred_modality:
            | Database["public"]["Enums"]["modality_type"]
            | null
          quantum_signature: string | null
          updated_at: string | null
          user_id: string
          username: string
          xr_enabled: boolean | null
        }
        Insert: {
          audio_enabled?: boolean | null
          avatar_url?: string | null
          bio?: string | null
          created_at?: string | null
          display_name?: string | null
          emotion_intensity?: number | null
          emotion_state?: Database["public"]["Enums"]["emotion_type"] | null
          haptic_enabled?: boolean | null
          id?: string
          id_nvida?: string | null
          institutional_weight?: number | null
          onboarding_completed?: boolean | null
          preferred_modality?:
            | Database["public"]["Enums"]["modality_type"]
            | null
          quantum_signature?: string | null
          updated_at?: string | null
          user_id: string
          username: string
          xr_enabled?: boolean | null
        }
        Update: {
          audio_enabled?: boolean | null
          avatar_url?: string | null
          bio?: string | null
          created_at?: string | null
          display_name?: string | null
          emotion_intensity?: number | null
          emotion_state?: Database["public"]["Enums"]["emotion_type"] | null
          haptic_enabled?: boolean | null
          id?: string
          id_nvida?: string | null
          institutional_weight?: number | null
          onboarding_completed?: boolean | null
          preferred_modality?:
            | Database["public"]["Enums"]["modality_type"]
            | null
          quantum_signature?: string | null
          updated_at?: string | null
          user_id?: string
          username?: string
          xr_enabled?: boolean | null
        }
        Relationships: []
      }
      quantum_pets: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          emotion: Database["public"]["Enums"]["emotion_type"] | null
          energy: number | null
          experience: number | null
          happiness: number | null
          health: number | null
          id: string
          level: number | null
          motto: string | null
          name: string
          pet_type: string
          quantum_bond: number | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string | null
          emotion?: Database["public"]["Enums"]["emotion_type"] | null
          energy?: number | null
          experience?: number | null
          happiness?: number | null
          health?: number | null
          id?: string
          level?: number | null
          motto?: string | null
          name: string
          pet_type: string
          quantum_bond?: number | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string | null
          emotion?: Database["public"]["Enums"]["emotion_type"] | null
          energy?: number | null
          experience?: number | null
          happiness?: number | null
          health?: number | null
          id?: string
          level?: number | null
          motto?: string | null
          name?: string
          pet_type?: string
          quantum_bond?: number | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      streamboard_posts: {
        Row: {
          comments: number | null
          content: string
          created_at: string | null
          emotion: Database["public"]["Enums"]["emotion_type"] | null
          id: string
          is_public: boolean | null
          likes: number | null
          media_urls: string[] | null
          post_type: string | null
          shares: number | null
          user_id: string
        }
        Insert: {
          comments?: number | null
          content: string
          created_at?: string | null
          emotion?: Database["public"]["Enums"]["emotion_type"] | null
          id?: string
          is_public?: boolean | null
          likes?: number | null
          media_urls?: string[] | null
          post_type?: string | null
          shares?: number | null
          user_id: string
        }
        Update: {
          comments?: number | null
          content?: string
          created_at?: string | null
          emotion?: Database["public"]["Enums"]["emotion_type"] | null
          id?: string
          is_public?: boolean | null
          likes?: number | null
          media_urls?: string[] | null
          post_type?: string | null
          shares?: number | null
          user_id?: string
        }
        Relationships: []
      }
      tamv_credits: {
        Row: {
          balance: number | null
          id: string
          lifetime_earnings: number | null
          resonance_credits: number | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          balance?: number | null
          id?: string
          lifetime_earnings?: number | null
          resonance_credits?: number | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          balance?: number | null
          id?: string
          lifetime_earnings?: number | null
          resonance_credits?: number | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      transactions: {
        Row: {
          amount: number
          created_at: string | null
          description: string | null
          id: string
          metadata: Json | null
          type: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string | null
          description?: string | null
          id?: string
          metadata?: Json | null
          type: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string | null
          description?: string | null
          id?: string
          metadata?: Json | null
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      university_courses: {
        Row: {
          category: string | null
          created_at: string | null
          description: string | null
          duration_hours: number | null
          id: string
          instructor_id: string | null
          is_published: boolean | null
          level: string | null
          thumbnail_url: string | null
          title: string
        }
        Insert: {
          category?: string | null
          created_at?: string | null
          description?: string | null
          duration_hours?: number | null
          id?: string
          instructor_id?: string | null
          is_published?: boolean | null
          level?: string | null
          thumbnail_url?: string | null
          title: string
        }
        Update: {
          category?: string | null
          created_at?: string | null
          description?: string | null
          duration_hours?: number | null
          id?: string
          instructor_id?: string | null
          is_published?: boolean | null
          level?: string | null
          thumbnail_url?: string | null
          title?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role:
        | "admin"
        | "architect"
        | "ambassador"
        | "curator"
        | "strategist"
        | "analyst"
        | "user"
      asset_type:
        | "dreamspace"
        | "nft"
        | "artwork"
        | "course"
        | "template"
        | "quantum_pet"
      compliance_level: "green" | "yellow" | "red"
      emotion_type:
        | "trust"
        | "inspiration"
        | "authority"
        | "care"
        | "empathy"
        | "conflict"
        | "resolve"
        | "joy"
        | "fear"
        | "surprise"
        | "sadness"
        | "disgust"
        | "anger"
        | "anticipation"
        | "neutral"
      modality_type: "visual" | "audio" | "tactile" | "hybrid"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "admin",
        "architect",
        "ambassador",
        "curator",
        "strategist",
        "analyst",
        "user",
      ],
      asset_type: [
        "dreamspace",
        "nft",
        "artwork",
        "course",
        "template",
        "quantum_pet",
      ],
      compliance_level: ["green", "yellow", "red"],
      emotion_type: [
        "trust",
        "inspiration",
        "authority",
        "care",
        "empathy",
        "conflict",
        "resolve",
        "joy",
        "fear",
        "surprise",
        "sadness",
        "disgust",
        "anger",
        "anticipation",
        "neutral",
      ],
      modality_type: ["visual", "audio", "tactile", "hybrid"],
    },
  },
} as const
