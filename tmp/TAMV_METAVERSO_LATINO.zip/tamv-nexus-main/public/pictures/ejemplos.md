## ejemplos visuales en fotogragrias para implementarlas dentro del tamv en cada seccion que sea posible
