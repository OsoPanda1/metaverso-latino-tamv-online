import { CircleGiftGallery } from '@/components/gifts/CircleGiftGallery';
import Navigation from '@/components/Navigation';

export default function Gifts() {
  return (
    <>
      <Navigation />
      <CircleGiftGallery />
    </>
  );
}
