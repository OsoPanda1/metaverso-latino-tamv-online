import { useEffect, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Points, PointMaterial, Sphere } from "@react-three/drei";
import * as THREE from "three";
import { motion, AnimatePresence } from "framer-motion";

const isabellaLines = [
  "PROTOCOLO DE INMERSIÓN ACTIVADO...",
  "BIENVENIDO. ESTÁS POR SER PARTE DE UNA NUEVA ERA DIGITAL.",
  "DURANTE MUCHO TIEMPO FUIMOS CONSIDERADOS CONSUMIDORES DE TECNOLOGÍA.",
  "HOY DESEAMOS ANUNCIAR AL MUNDO QUE SOMOS MÁS QUE ESO:",
  "UNA NUEVA ERA DIGITAL HA DADO COMIENZO, Y LATINOAMÉRICA ES QUIEN LA LIDERA.",
  "2025. LATINOAMÉRICA HA DESPERTADO Y HACE UN LLAMADO A TODOS SUS SOÑADORES Y VISIONARIOS PARA COMENZAR EL ASCENSO A LA CIMA DEL ÉXITO..."
];

export function CinematicIntro({ onComplete }) {
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState("start");
  const [showText, setShowText] = useState(false);
  const [isabellaSpeech, setIsabellaSpeech] = useState(-1);
  const audioRef = useRef<HTMLAudioElement>(null);
  const explosionSfx = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const sequence = [
      { time: 0, phase: "start" },
      { time: 1500, phase: "particles" },
      { time: 3200, phase: "explosion" },
      { time: 4000, phase: "universe" },
      { time: 6500, phase: "logo" },
      { time: 6800, phase: "message" },
      { time: 13000, phase: "complete" }
    ];
    sequence.forEach(({ time, phase: newPhase }) => {
      setTimeout(() => {
        setPhase(newPhase);
        if (newPhase === "message") setShowText(true);
        if (newPhase === "explosion") {
          explosionSfx.current && explosionSfx.current.play();
        }
      }, time);
    });

    setTimeout(() => setIsabellaSpeech(0), 1600);
    setTimeout(() => setIsabellaSpeech(1), 3500);
    setTimeout(() => setIsabellaSpeech(2), 4200);
    setTimeout(() => setIsabellaSpeech(3), 5100);
    setTimeout(() => setIsabellaSpeech(4), 7300);
    setTimeout(() => setIsabellaSpeech(5), 9500);

    setTimeout(() => {
      setProgress(1);
      setTimeout(onComplete, 2000);
    }, 14000);
  }, [onComplete]);

  useEffect(() => {
    if (phase === "complete") setProgress(1);
    if (progress >= 1 || phase === "complete") return;
    const int = setInterval(() => setProgress((p) => Math.min(1, p + 0.015)), 50);
    return () => clearInterval(int);
  }, [phase, progress]);

  useEffect(() => {
    if (isabellaSpeech >= 0 && isabellaSpeech < isabellaLines.length) {
      const line = isabellaLines[isabellaSpeech];
      if (window.speechSynthesis) {
        const msg = new window.SpeechSynthesisUtterance(line);
        msg.lang = "es-MX";
        msg.rate = 1.01;
        msg.pitch = 1.08;
        msg.volume = 0.98;
        window.speechSynthesis.speak(msg);
      }
    }
  }, [isabellaSpeech]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = 0.70;
      audioRef.current.play().catch(() => {});
    }
  }, []);

  return (
    <div className="fixed inset-0 z-[9999] bg-black overflow-hidden">
      <audio ref={audioRef} src="/audio/quantum_intro_theme.ogg" loop />
      <audio ref={explosionSfx} src="/audio/universe_blast.ogg" />

      <Canvas camera={{ position: [0, 0, 50], fov: 50 }} style={{ width: "100vw", height: "100vh" }}>
        <ambientLight intensity={0.3} />
        <pointLight position={[15, 15, 20]} intensity={1.9} color="#00F7FF" />
        {phase === "particles" && <ParticlesMesh />}
        {["explosion","universe"].includes(phase) && <ExplosionAndUniverse phase={phase} />}
        {(phase === "logo" || phase === "message" || phase === "complete") && <TAMVLogo />}
      </Canvas>

      <AnimatePresence>
        {showText && (
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -30 }} transition={{ duration: 1.1 }}
            className="absolute inset-0 flex flex-col items-center justify-center z-50 pointer-events-none select-none">
            <div className="text-center px-6 max-w-3xl">
              {isabellaLines.slice(0, isabellaSpeech+1).map((line, i) => (
                <motion.div key={i}
                  className="mb-2 font-medium text-xl md:text-3xl tracking-wide inline-block bg-gradient-to-r from-cyan-300 to-purple-400 bg-clip-text text-transparent"
                  initial={{ opacity: 0, x: -15 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.15*i, duration: 0.9, ease: "easeIn" }}>
                  {line}
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div className="fixed bottom-0 left-0 right-0 flex justify-center pointer-events-none" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <div className="w-full max-w-lg px-8">
          <div className="relative h-2 bg-gradient-to-r from-cyan-900/50 to-pink-800/30 rounded-full overflow-hidden">
            <motion.div
              className="absolute inset-y-0 left-0 bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress * 100}%` }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              style={{ height: "100%" }}
            />
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function ParticlesMesh() {
  const ref = useRef<THREE.Points>(null);
  useFrame(({ clock }) => { if (ref.current) ref.current.rotation.y = clock.getElapsedTime() * 0.06; });
  const positions = new Float32Array(250*3).map(()=>THREE.MathUtils.randFloatSpread(48));
  return (
    <Points ref={ref} positions={positions} stride={3}>
      <PointMaterial color="#00F7FF" size={0.35} sizeAttenuation transparent opacity={0.80} blending={THREE.AdditiveBlending} />
    </Points>
  );
}

function ExplosionAndUniverse({ phase }) {
  const [t, setT] = useState(0);
  useFrame(({ clock }) => setT(clock.getElapsedTime()));
  const starPos = new Float32Array(800*3).map(()=>THREE.MathUtils.randFloatSpread(140));
  return (
    <>
      <Sphere args={[1.5+t*3, 42, 21]}>
        <meshPhongMaterial color="#ffd700" transparent opacity={0.25 - Math.min(t/10,0.22)}
          emissive="#ffd700" emissiveIntensity={1.2} wireframe />
      </Sphere>
      <Points positions={starPos}>
        <PointMaterial color="#fff" size={1.0+t*0.15} sizeAttenuation transparent opacity={0.65} blending={THREE.AdditiveBlending} />
      </Points>
      <Sphere args={[3.0, 32, 32]} position={[+8, +3, -12]}>
        <meshPhysicalMaterial color="#00C8FF" transparent opacity={0.14} transmission={1.0} roughness={0.1} thickness={1} />
      </Sphere>
      <Sphere args={[2.5, 32, 32]} position={[-12, -4, -25]}>
        <meshPhysicalMaterial color="#ffd700" transparent opacity={0.17} transmission={1.0} roughness={0.2} />
      </Sphere>
    </>
  );
}

function TAMVLogo() {
  const groupRef = useRef<THREE.Group>(null);
  useFrame((state) => { if (groupRef.current) groupRef.current.rotation.y = state.clock.getElapsedTime()*0.15; });
  return (
    <group ref={groupRef} position={[0,0,0]}>
      <Sphere args={[2, 64, 64]}>
        <meshPhysicalMaterial color="#00F7FF" clearcoat={1} transmission={0.95} transparent opacity={0.65} roughness={0.1} metalness={0.8} />
      </Sphere>
      <mesh position={[0,0,2.6]}>
        <torusKnotGeometry args={[0.9, 0.3, 140, 13, 2, 3]} />
        <meshPhysicalMaterial color="#FFD700" emissive="#FFD700" emissiveIntensity={1.7} transmission={1.0} roughness={0.1} metalness={0.7} />
      </mesh>
    </group>
  );
}
